"""
speaker_detection.py

Speaker Detection & Audio Recording Module
===========================================

Logic:
  1. Every detected person gets a speaker_confidence_score in [0.0, 1.0].
  2. The person with the HIGHEST score is declared the active speaker.
  3. That person's ID is used to name & record the audio file:
        recordings/<person_id>_<timestamp>.wav
  4. Recording stops the moment a different person takes over as speaker.

Confidence score is computed from three visual signals:
  ┌─────────────────┬────────┬──────────────────────────────────────┐
  │ Signal          │ Weight │ Rationale                            │
  ├─────────────────┼────────┼──────────────────────────────────────┤
  │ Mouth movement  │  0.55  │ Primary cue – mouth opens to speak   │
  │ Head pose       │  0.25  │ Looking at camera → likely speaking  │
  │ Emotion         │  0.20  │ Animated face reinforces speech      │
  └─────────────────┴────────┴──────────────────────────────────────┘

Voice energy (VAD) is NOT used as a per-face weight here because
the microphone hears the ROOM, not individual faces.  Instead, VAD
acts as a gate: if the room is silent (energy < VAD_GATE), no one
is declared the active speaker regardless of visual scores.
"""

import os
import math
import struct
import time
import threading
import wave

# ---------------------------------------------------------------------------
# Weights  (must sum to 1.0)
# ---------------------------------------------------------------------------
W_MOUTH   = 0.55
W_POSE    = 0.25
W_EMOTION = 0.20

# ---------------------------------------------------------------------------
# Emotion → speech-likelihood lookup
# ---------------------------------------------------------------------------
EMOTION_SPEECH_WEIGHT = {
    "Happy":     1.00,
    "Surprised": 0.90,
    "Angry":     0.85,
    "Neutral":   0.50,
    "Fearful":   0.55,
    "Disgusted": 0.50,
    "Sad":       0.35,
}

# ---------------------------------------------------------------------------
# VAD gate – if room energy is below this the speaker is set to None
# ---------------------------------------------------------------------------
VAD_GATE = 0.08   # tune to your mic / room noise floor

# ---------------------------------------------------------------------------
# Minimum visual score required to be declared speaker even when VAD passes
# ---------------------------------------------------------------------------
MIN_VISUAL_SCORE = 0.20

# ---------------------------------------------------------------------------
# Audio recording config
# ---------------------------------------------------------------------------
AUDIO_RATE     = 16000
AUDIO_CHANNELS = 1
SAMPLE_WIDTH   = 2          # bytes  (16-bit PCM)
RECORDINGS_DIR = "recordings"


# ===========================================================================
# Per-face confidence score
# ===========================================================================

def _mouth_score(mouth_gap: float, mouth_w: float) -> float:
    """
    Normalised mouth-openness ratio, resolution-independent.
    A ratio ≥ 0.35 maps to full score (clearly speaking).
    """
    if mouth_w < 1.0:
        return 0.0
    ratio = mouth_gap / mouth_w
    return min(ratio / 0.35, 1.0)


def _pose_score(yaw: float, pitch: float) -> float:
    """
    Score is 1.0 when looking straight at camera, drops as head turns.
    yaw/pitch are in the −100…+100 range produced by pose.py.
    """
    yaw_norm   = min(abs(yaw)   / 45.0, 1.0)   # 45 units → fully turned
    pitch_norm = min(abs(pitch) / 30.0, 1.0)   # 30 units → fully up/down
    penalty    = yaw_norm * 0.65 + pitch_norm * 0.35
    return round(1.0 - penalty, 4)


def _emotion_score(emotion: str) -> float:
    return EMOTION_SPEECH_WEIGHT.get(emotion, 0.50)


def compute_confidence_score(
    mouth_gap:   float,
    mouth_width: float,
    head_pose:   tuple,          # (yaw, pitch, roll)
    emotion:     str = "Neutral",
) -> float:
    """
    Compute the speaker confidence score for ONE face.

    Returns a float in [0.0, 1.0].
    Higher = more likely this person is currently speaking.

    Parameters
    ----------
    mouth_gap   : vertical distance between upper & lower lip (pixels)
    mouth_width : horizontal mouth width (pixels)
    head_pose   : (yaw, pitch, roll) from pose.py
    emotion     : emotion string from expressions.py
    """
    yaw, pitch, _ = head_pose

    m = _mouth_score(mouth_gap, mouth_width)
    p = _pose_score(yaw, pitch)
    e = _emotion_score(emotion)

    score = W_MOUTH * m + W_POSE * p + W_EMOTION * e
    return round(min(max(score, 0.0), 1.0), 4)


# ===========================================================================
# Active speaker selection
# ===========================================================================

def identify_active_speaker(
    scores:       dict,    # { person_id: confidence_score }
    voice_energy: float,   # room-level VAD energy  0.0–1.0
) -> tuple:
    """
    Given confidence scores for every visible person and the current
    room voice energy, return (active_speaker_id, scores_dict).

    Rules
    -----
    • If room is silent  (voice_energy < VAD_GATE)  → no active speaker.
    • Else the person with the highest visual score wins,
      provided their score is above MIN_VISUAL_SCORE.

    Returns
    -------
    (active_speaker_id | None,  scores_dict)
    scores_dict is identical to the input `scores` – returned for
    convenience so callers only need to call this function.
    """
    if not scores:
        return None, scores

    if voice_energy < VAD_GATE:
        return None, scores

    best_id    = max(scores, key=scores.get)
    best_score = scores[best_id]

    if best_score < MIN_VISUAL_SCORE:
        return None, scores

    return best_id, scores


# ===========================================================================
# VAD — room-level voice energy from raw PCM bytes
# ===========================================================================

def compute_voice_energy(audio_chunk: bytes, sample_width: int = 2) -> float:
    """
    Estimate voice energy from a raw 16-bit PCM audio chunk.

    Returns
    -------
    energy : float in [0.0, 1.0]
    """
    if not audio_chunk:
        return 0.0

    n_samples = len(audio_chunk) // sample_width
    if n_samples == 0:
        return 0.0

    fmt     = f"{n_samples}h"
    samples = struct.unpack(fmt, audio_chunk[:n_samples * sample_width])
    rms     = math.sqrt(sum(s * s for s in samples) / n_samples)

    SILENCE_FLOOR = 200.0
    MAX_AMP       = 32767.0

    if rms < SILENCE_FLOOR:
        return 0.0

    energy = (rms - SILENCE_FLOOR) / (MAX_AMP - SILENCE_FLOOR)
    return round(min(energy, 1.0), 4)


# ===========================================================================
# Audio Recorder  —  writes WAV per active-speaker segment
# ===========================================================================

class SpeakerAudioRecorder:
    """
    Records audio attributed to the active speaker.

    When the active speaker changes, the current WAV file is closed and
    a new one is opened for the new speaker.

    Files are written to:
        recordings/<person_id>_<unix_timestamp>.wav

    Usage
    -----
        recorder = SpeakerAudioRecorder()
        # inside the audio-capture callback:
        recorder.write(chunk, active_speaker_id)
        # on shutdown:
        recorder.close()
    """

    def __init__(self, rate: int = AUDIO_RATE, channels: int = AUDIO_CHANNELS,
                 sample_width: int = SAMPLE_WIDTH):
        os.makedirs(RECORDINGS_DIR, exist_ok=True)

        self._rate         = rate
        self._channels     = channels
        self._sample_width = sample_width

        self._current_id   = None   # currently-recording speaker ID
        self._wav_file     = None   # open wave.Wave_write object
        self._lock         = threading.Lock()

        self._session_log  = []     # list of (person_id, filepath, duration_s)

    # ------------------------------------------------------------------
    def write(self, pcm_chunk: bytes, active_speaker_id):
        """
        Call this for every audio chunk arriving from PyAudio.

        If active_speaker_id differs from the current recording speaker,
        the file is rotated automatically.

        Parameters
        ----------
        pcm_chunk          : raw 16-bit PCM bytes from PyAudio
        active_speaker_id  : str | None   (None = silence / no speaker)
        """
        with self._lock:
            if active_speaker_id != self._current_id:
                self._rotate(active_speaker_id)

            if self._wav_file and active_speaker_id is not None:
                self._wav_file.writeframes(pcm_chunk)

    # ------------------------------------------------------------------
    def close(self):
        """Finalise and close any open WAV file."""
        with self._lock:
            self._close_current()

    # ------------------------------------------------------------------
    def session_log(self) -> list:
        """Return list of completed recordings: [(id, path, duration_s)]."""
        return list(self._session_log)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _rotate(self, new_id):
        """Close current file (if any) and open a new one for new_id."""
        self._close_current()
        self._current_id = new_id

        if new_id is not None:
            ts       = int(time.time())
            filename = os.path.join(RECORDINGS_DIR, f"{new_id}_{ts}.wav")
            wf = wave.open(filename, "wb")
            wf.setnchannels(self._channels)
            wf.setsampwidth(self._sample_width)
            wf.setframerate(self._rate)
            self._wav_file      = wf
            self._current_path  = filename
            self._start_time    = time.time()
            print(f"[REC] ▶ Recording started → {filename}  (speaker: {new_id})")

    def _close_current(self):
        if self._wav_file is not None:
            self._wav_file.close()
            duration = round(time.time() - self._start_time, 2)
            self._session_log.append(
                (self._current_id, self._current_path, duration)
            )
            print(f"[REC] ■ Recording saved   → {self._current_path}"
                  f"  ({duration:.1f} s)")
            self._wav_file = None
