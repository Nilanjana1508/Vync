"""
receiver.py  —  RECEIVER
=========================
Semantic Video Conferencing System

What this does
--------------
  1. Listens on a WebSocket port for incoming frames from the sender.
  2. Text frames  → JSON semantic packet
       • Parse person IDs, emotions, head poses, speaker scores
       • Feed into TalkingFaceGenerator → animated avatar per person
       • Display all participants in an OpenCV window
  3. Binary frames → raw PCM audio (16-bit mono 16 kHz)
       • Play through the local speakers in real time via PyAudio
       • This is the active speaker's voice — other participants hear it

So when P002 speaks on the sender side:
  sender audio thread  →  binary WebSocket frame (PCM chunk)
  receiver audio thread ←  receives chunk  →  PyAudio output  →  speakers

Run
---
  python receiver.py                    # listen on 0.0.0.0:8765
  python receiver.py --host 0.0.0.0 --port 8765
  python receiver.py --no-audio         # display only, mute output

Controls:  q = quit
"""

import argparse
import asyncio
import queue
import threading
import time

import cv2
import numpy as np

try:
    import websockets
    WS_AVAILABLE = True
except ImportError:
    WS_AVAILABLE = False
    print("[ERROR] Install websockets:  pip install websockets")

try:
    import pyaudio
    AUDIO_AVAILABLE = True
except ImportError:
    AUDIO_AVAILABLE = False
    print("[WARNING] pyaudio not installed — audio playback disabled.")

from semantic_packet import parse_packet, get_active_speaker_data
from audio_codec import decompress_chunk, CODEC_NAME

# ===========================================================================
# Audio config  (must match sender)
# ===========================================================================
AUDIO_RATE     = 16000
AUDIO_CHANNELS = 1
AUDIO_FORMAT   = 8         # pyaudio.paInt16
SAMPLE_WIDTH   = 2         # bytes per sample

# ===========================================================================
# Audio playback thread
# ===========================================================================

class AudioPlayer:
    """
    Plays raw PCM chunks received from the WebSocket on the local speakers.

    Chunks arrive from the network thread and are queued here so playback
    never blocks the WebSocket receiver.  A jitter buffer (maxsize=40 ≈ 2.5 s)
    prevents unbounded memory growth if the network is faster than playback.
    """

    def __init__(self):
        self._queue   = queue.Queue(maxsize=40)
        self._running = False
        self._thread  = None
        self._stream  = None
        self._pa      = None

    def start(self):
        if not AUDIO_AVAILABLE:
            return
        self._running = True
        self._thread  = threading.Thread(target=self._run, daemon=True)
        self._thread.start()
        print("[AUDIO] Playback started — you will hear the active speaker.")

    def stop(self):
        self._running = False
        if self._thread:
            self._thread.join(timeout=3)

    def enqueue(self, compressed: bytes):
        """Called from the network thread. Decompresses then queues PCM."""
        try:
            pcm = decompress_chunk(compressed)
            self._queue.put_nowait(pcm)
        except queue.Full:
            pass   # drop oldest-equivalent chunk; prefer low latency

    def _run(self):
        self._pa     = pyaudio.PyAudio()
        self._stream = self._pa.open(
            rate              = AUDIO_RATE,
            channels          = AUDIO_CHANNELS,
            format            = AUDIO_FORMAT,
            output            = True,
            frames_per_buffer = 1024,
        )
        while self._running:
            try:
                chunk = self._queue.get(timeout=0.1)
                self._stream.write(chunk)
            except queue.Empty:
                # Nothing to play — write silence so stream stays alive
                silence = b"\x00" * 1024 * SAMPLE_WIDTH
                self._stream.write(silence)
            except Exception as exc:
                print(f"[AUDIO] Playback error: {exc}")

        self._stream.stop_stream()
        self._stream.close()
        self._pa.terminate()


# ===========================================================================
# Talking Face Generator  (stub — replace with your model)
# ===========================================================================

AVATAR_W, AVATAR_H = 260, 260

EMOTION_COLORS = {
    "Happy":     (0,   220,  50),
    "Sad":       (200,  80,   0),
    "Angry":     (0,    0,  240),
    "Surprised": (0,   200, 240),
    "Fearful":   (140,  0,  180),
    "Disgusted": (0,   150, 100),
    "Neutral":   (150, 150, 150),
}


class TalkingFaceGenerator:
    """
    Stub face generator — draws animated avatar from semantic data.

    Replace render() with your real model call (SadTalker, DiffTalk, FOMM …).
    The method signature accepts all fields a talking-face model needs.
    """

    def render(
        self,
        person_id:         str,
        emotion:           str,
        emotion_confidence: float,
        yaw:               float,
        pitch:             float,
        roll:              float,
        speaker_score:     float,
        is_active_speaker: bool,
    ) -> np.ndarray:
        canvas = np.zeros((AVATAR_H, AVATAR_W, 3), dtype=np.uint8)
        col    = EMOTION_COLORS.get(emotion, (150,150,150))

        # Tinted background
        canvas[:] = tuple(max(c//5, 0) for c in col)

        # Head shift simulates yaw/pitch
        sx = int(yaw   * 0.55)
        sy = int(pitch * 0.38)
        cx, cy = AVATAR_W//2 + sx, AVATAR_H//2 + sy

        # Face oval
        cv2.ellipse(canvas, (cx,cy), (82,100), 0, 0, 360, col, -1)

        # Eyes
        ey = cy - 28
        cv2.circle(canvas, (cx-30, ey), 11, (30,30,30), -1)
        cv2.circle(canvas, (cx+30, ey), 11, (30,30,30), -1)

        # Mouth — opens proportionally to speaker_score
        mouth_open = int(22 * speaker_score)
        my = cy + 36
        if mouth_open > 3:
            cv2.ellipse(canvas,(cx,my),(28,mouth_open),0,0,180,(20,20,20),-1)
        else:
            cv2.line(canvas,(cx-26,my),(cx+26,my),(20,20,20),3)

        # Active speaker border (cyan)
        if is_active_speaker:
            cv2.rectangle(canvas,(2,2),(AVATAR_W-3,AVATAR_H-3),(0,255,255),4)

        # Labels
        cv2.putText(canvas, person_id,
                    (8,22), cv2.FONT_HERSHEY_SIMPLEX, 0.65, (255,255,255), 2)
        cv2.putText(canvas, emotion,
                    (8, AVATAR_H-32), cv2.FONT_HERSHEY_SIMPLEX,
                    0.50, (255,255,255), 1)
        cv2.putText(canvas, f"score {speaker_score:.2f}",
                    (8, AVATAR_H-12), cv2.FONT_HERSHEY_SIMPLEX,
                    0.45, (200,255,200), 1)

        if is_active_speaker:
            cv2.putText(canvas, "SPEAKING",
                        (AVATAR_W-95, 22),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.52, (0,255,255), 2)
        return canvas


# ===========================================================================
# WebSocket server
# ===========================================================================

class WSReceiver:
    """
    Listens for WebSocket connections from the sender.

    Incoming text frames  → semantic packet queue
    Incoming binary frames → audio player
    """

    def __init__(self, host: str, port: int,
                 audio_player: AudioPlayer, no_audio: bool):
        self._host         = host
        self._port         = port
        self._audio_player = audio_player
        self._no_audio     = no_audio

        self._pkt_queue  = queue.Queue(maxsize=60)
        self._loop       = asyncio.new_event_loop()
        self._thread     = threading.Thread(
            target=self._run_loop, daemon=True)

    def start(self):
        self._thread.start()

    def get_latest_packet(self) -> dict | None:
        """Drain queue, return the most recent packet."""
        latest = None
        while not self._pkt_queue.empty():
            try:
                latest = self._pkt_queue.get_nowait()
            except queue.Empty:
                break
        return latest

    def _run_loop(self):
        asyncio.set_event_loop(self._loop)
        self._loop.run_until_complete(self._serve())

    async def _serve(self):
        async def handler(ws):
            addr = ws.remote_address
            print(f"[WS] Sender connected: {addr}")
            try:
                async for msg in ws:
                    if isinstance(msg, str):
                        # ── Text frame: semantic JSON packet ─────────────────
                        try:
                            pkt = parse_packet(msg)
                            if not self._pkt_queue.full():
                                self._pkt_queue.put_nowait(pkt)
                        except Exception as e:
                            print(f"[WS] JSON parse error: {e}")
                    elif isinstance(msg, bytes):
                        # ── Binary frame: compressed audio ───────────────────
                        # enqueue() decompresses to PCM before queuing
                        if not self._no_audio:
                            self._audio_player.enqueue(msg)
            except Exception as exc:
                print(f"[WS] Connection closed ({addr}): {exc}")

        async with websockets.serve(handler, self._host, self._port):
            print(f"[WS] Listening on ws://{self._host}:{self._port}")
            await asyncio.Future()   # run forever


# ===========================================================================
# Frame builder
# ===========================================================================

def build_display_frame(packet: dict,
                         generator: TalkingFaceGenerator) -> np.ndarray:
    people         = packet.get("people", [])
    active_speaker = packet.get("active_speaker")

    if not people:
        blank = np.zeros((AVATAR_H, AVATAR_W, 3), dtype=np.uint8)
        cv2.putText(blank, "No participants",
                    (10, AVATAR_H//2), cv2.FONT_HERSHEY_SIMPLEX,
                    0.6, (160,160,160), 1)
        return blank

    avatars = [
        generator.render(
            person_id          = p["id"],
            emotion            = p.get("emotion","Neutral"),
            emotion_confidence = p.get("emotion_confidence", 0.0),
            yaw                = p.get("head_pose",{}).get("yaw",  0.0),
            pitch              = p.get("head_pose",{}).get("pitch",0.0),
            roll               = p.get("head_pose",{}).get("roll", 0.0),
            speaker_score      = p.get("speaker_score", 0.0),
            is_active_speaker  = (p["id"] == active_speaker),
        )
        for p in people
    ]

    composite = np.hstack(avatars)

    # Status bar
    ts  = time.strftime("%H:%M:%S", time.localtime(packet.get("timestamp",0)))
    spk = active_speaker or "—"
    bar = np.zeros((36, composite.shape[1], 3), dtype=np.uint8)
    cv2.putText(bar,
                f"{ts}  |  Speaker: {spk}  |  {len(people)} participant(s)",
                (8,24), cv2.FONT_HERSHEY_SIMPLEX, 0.52, (180,255,180), 1)

    return np.vstack([composite, bar])


# ===========================================================================
# Main
# ===========================================================================

def run_receiver(args):
    generator    = TalkingFaceGenerator()
    audio_player = AudioPlayer()

    if not args.no_audio:
        audio_player.start()

    ws_recv = None
    if WS_AVAILABLE:
        ws_recv = WSReceiver(args.host, args.port, audio_player, args.no_audio)
        ws_recv.start()
    else:
        print("[ERROR] websockets required. pip install websockets")
        return

    # Default placeholder frame
    last_frame = np.zeros((AVATAR_H + 36, AVATAR_W, 3), dtype=np.uint8)
    cv2.putText(last_frame, "Waiting for sender …",
                (10, AVATAR_H//2), cv2.FONT_HERSHEY_SIMPLEX,
                0.6, (160,160,160), 1)

    print("[INFO] Receiver running — press 'q' to quit.")
    if not args.no_audio:
        print(f"[INFO] Audio codec  : {CODEC_NAME.upper()} (decompress → speakers)")
        print("[INFO] Audio output : you will hear the active speaker's voice.")

    while True:
        packet = ws_recv.get_latest_packet()
        if packet:
            last_frame = build_display_frame(packet, generator)

        cv2.imshow("Semantic Receiver — Remote Participants", last_frame)
        if cv2.waitKey(30) & 0xFF == ord("q"):
            break

    audio_player.stop()
    cv2.destroyAllWindows()
    print("[INFO] Receiver stopped.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Semantic VC — Receiver")
    parser.add_argument("--host", type=str, default="0.0.0.0",
        help="Bind address (default 0.0.0.0 = accept any sender)")
    parser.add_argument("--port", type=int, default=8765)
    parser.add_argument("--no-audio", action="store_true",
        help="Disable audio playback (display only)")
    run_receiver(parser.parse_args())
