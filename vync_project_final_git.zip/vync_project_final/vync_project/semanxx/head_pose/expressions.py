
"""
expressions.py
Lightweight facial expression module.
Returns only emotion and confidence.
"""

import math

LEFT_MOUTH=61
RIGHT_MOUTH=291
UPPER_LIP=13
LOWER_LIP=14
LEFT_EYE_TOP=159
LEFT_EYE_BOTTOM=145
RIGHT_EYE_TOP=386
RIGHT_EYE_BOTTOM=374
LEFT_EYEBROW=70
RIGHT_EYEBROW=300
LEFT_EYE=33
RIGHT_EYE=263

def _pt(face_landmarks,i,w,h):
    lm=face_landmarks.landmark[i]
    return lm.x*w,lm.y*h

def _dist(a,b):
    return math.hypot(a[0]-b[0],a[1]-b[1])

def mouth_gap(fl,w,h):
    return _dist(_pt(fl,UPPER_LIP,w,h),_pt(fl,LOWER_LIP,w,h))

def mouth_width(fl,w,h):
    return _dist(_pt(fl,LEFT_MOUTH,w,h),_pt(fl,RIGHT_MOUTH,w,h))

def eye_opening(fl,w,h):
    l=_dist(_pt(fl,LEFT_EYE_TOP,w,h),_pt(fl,LEFT_EYE_BOTTOM,w,h))
    r=_dist(_pt(fl,RIGHT_EYE_TOP,w,h),_pt(fl,RIGHT_EYE_BOTTOM,w,h))
    return (l+r)/2

def eyebrow_height(fl,w,h):
    l=_dist(_pt(fl,LEFT_EYEBROW,w,h),_pt(fl,LEFT_EYE,w,h))
    r=_dist(_pt(fl,RIGHT_EYEBROW,w,h),_pt(fl,RIGHT_EYE,w,h))
    return (l+r)/2

def classify_emotion(fl,w,h):
    gap=mouth_gap(fl,w,h)
    width=mouth_width(fl,w,h)
    eye=eye_opening(fl,w,h)
    brow=eyebrow_height(fl,w,h)
    ratio=gap/max(width,1)

    if ratio>0.38 and brow>22:
        return "Surprised",0.82
    if width>95 and ratio>0.18:
        return "Happy",0.86
    if eye<7:
        return "Sad",0.70
    if brow<12:
        return "Angry",0.72
    return "Neutral",0.90

def analyze_expression(face_landmarks,frame_width,frame_height):
    emotion,confidence=classify_emotion(face_landmarks,frame_width,frame_height)
    return {"emotion":emotion,"confidence":round(confidence,2)}

def draw_expression(frame,result):
    import cv2
    cv2.putText(frame,f'Emotion: {result["emotion"]}',(20,310),cv2.FONT_HERSHEY_SIMPLEX,0.7,(255,255,0),2)
    cv2.putText(frame,f'Confidence: {result["confidence"]:.2f}',(20,340),cv2.FONT_HERSHEY_SIMPLEX,0.7,(255,255,0),2)
