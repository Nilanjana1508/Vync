"""
pose.py

Simple Head Pose Estimation
using MediaPipe Face Mesh landmarks.

Outputs:
- Yaw
- Pitch
- Roll
- Looking at Camera
"""

import math

# -------------------------------
# Landmark IDs
# -------------------------------

NOSE = 1

LEFT_EYE = 33
RIGHT_EYE = 263

LEFT_MOUTH = 61
RIGHT_MOUTH = 291

FOREHEAD = 10

CHIN = 152


# -------------------------------
# Convert landmark to pixel
# -------------------------------

def point(face_landmarks, index, width, height):

    lm = face_landmarks.landmark[index]

    return (
        lm.x * width,
        lm.y * height
    )


# -------------------------------
# Distance
# -------------------------------

def distance(p1, p2):

    return math.sqrt(

        (p1[0]-p2[0])**2 +

        (p1[1]-p2[1])**2

    )


# -------------------------------
# Roll
# -------------------------------

def estimate_roll(face_landmarks,
                  width,
                  height):

    left = point(face_landmarks,
                 LEFT_EYE,
                 width,
                 height)

    right = point(face_landmarks,
                  RIGHT_EYE,
                  width,
                  height)

    dx = right[0]-left[0]

    dy = right[1]-left[1]

    angle = math.degrees(

        math.atan2(dy, dx)

    )

    return angle


# -------------------------------
# Yaw
# -------------------------------

def estimate_yaw(face_landmarks,
                 width,
                 height):

    left_eye = point(face_landmarks,
                     LEFT_EYE,
                     width,
                     height)

    right_eye = point(face_landmarks,
                      RIGHT_EYE,
                      width,
                      height)

    nose = point(face_landmarks,
                 NOSE,
                 width,
                 height)

    left = distance(
        left_eye,
        nose
    )

    right = distance(
        right_eye,
        nose
    )

    total = left + right

    if total == 0:
        return 0

    ratio = (right-left)/total

    return ratio*100


# -------------------------------
# Pitch
# -------------------------------

def estimate_pitch(face_landmarks,
                   width,
                   height):

    eyes = (

        (point(face_landmarks,
               LEFT_EYE,
               width,
               height)[1]

         +

         point(face_landmarks,
               RIGHT_EYE,
               width,
               height)[1])

        /2

    )

    nose = point(face_landmarks,
                 NOSE,
                 width,
                 height)[1]

    mouth = (

        (point(face_landmarks,
               LEFT_MOUTH,
               width,
               height)[1]

         +

         point(face_landmarks,
               RIGHT_MOUTH,
               width,
               height)[1])

        /2

    )

    upper = nose-eyes

    lower = mouth-nose

    total = upper+lower

    if total == 0:
        return 0

    ratio = (upper-lower)/total

    return ratio*100


# -------------------------------
# Combined
# -------------------------------

def estimate_head_pose(face_landmarks,
                       width,
                       height):

    yaw = estimate_yaw(
        face_landmarks,
        width,
        height
    )

    pitch = estimate_pitch(
        face_landmarks,
        width,
        height
    )

    roll = estimate_roll(
        face_landmarks,
        width,
        height
    )

    return yaw, pitch, roll


# -------------------------------
# Looking At Camera
# -------------------------------

def looking_at_camera(
        yaw,
        pitch,
        yaw_threshold=10,
        pitch_threshold=10
):

    return (

        abs(yaw) < yaw_threshold

        and

        abs(pitch) < pitch_threshold

    )


# -------------------------------
# Draw Values
# -------------------------------

def draw_pose_text(
        frame,
        yaw,
        pitch,
        roll
):

    import cv2

    cv2.putText(
        frame,
        f"Yaw : {yaw:.1f}",
        (20,180),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.6,
        (0,255,255),
        2
    )

    cv2.putText(
        frame,
        f"Pitch : {pitch:.1f}",
        (20,210),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.6,
        (0,255,255),
        2
    )

    cv2.putText(
        frame,
        f"Roll : {roll:.1f}",
        (20,240),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.6,
        (0,255,255),
        2
    )


# -------------------------------
# Draw Camera Status
# -------------------------------

def draw_camera_status(
        frame,
        looking
):

    import cv2

    if looking:

        color = (0,255,0)

        text = "Looking at Camera"

    else:

        color = (0,0,255)

        text = "Looking Away"

    cv2.putText(

        frame,

        text,

        (20,275),

        cv2.FONT_HERSHEY_SIMPLEX,

        0.8,

        color,

        2

    )