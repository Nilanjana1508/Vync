"""
geometry.py

Utility functions for facial geometry.

This module does NOT detect faces.
It only processes landmarks returned by MediaPipe Face Mesh.
"""

import math
import numpy as np

# -------------------------------------------------------
# Landmark IDs
# (MediaPipe Face Mesh)
# -------------------------------------------------------

NOSE_TIP = 1

LEFT_EYE = [33, 133]
RIGHT_EYE = [362, 263]

LEFT_EYE_CENTER = 33
RIGHT_EYE_CENTER = 263

LEFT_MOUTH = 61
RIGHT_MOUTH = 291

UPPER_LIP = 13
LOWER_LIP = 14

CHIN = 152

FOREHEAD = 10

# -------------------------------------------------------
# Coordinate Conversion
# -------------------------------------------------------

def landmark_to_pixel(landmark, frame_width, frame_height):
    """
    Convert MediaPipe normalized coordinates
    to pixel coordinates.
    """

    x = int(landmark.x * frame_width)
    y = int(landmark.y * frame_height)

    return (x, y)


# -------------------------------------------------------
# Euclidean Distance
# -------------------------------------------------------

def distance(p1, p2):

    return math.sqrt(
        (p1[0]-p2[0])**2 +
        (p1[1]-p2[1])**2
    )


# -------------------------------------------------------
# Midpoint
# -------------------------------------------------------

def midpoint(p1, p2):

    return (
        int((p1[0]+p2[0])/2),
        int((p1[1]+p2[1])/2)
    )


# -------------------------------------------------------
# Face Center
# -------------------------------------------------------

def face_center(face_landmarks, frame_width, frame_height):

    nose = landmark_to_pixel(
        face_landmarks.landmark[NOSE_TIP],
        frame_width,
        frame_height
    )

    chin = landmark_to_pixel(
        face_landmarks.landmark[CHIN],
        frame_width,
        frame_height
    )

    return midpoint(nose, chin)


# -------------------------------------------------------
# Mouth Opening
# -------------------------------------------------------

def mouth_opening(face_landmarks, frame_width, frame_height):

    upper = landmark_to_pixel(
        face_landmarks.landmark[UPPER_LIP],
        frame_width,
        frame_height
    )

    lower = landmark_to_pixel(
        face_landmarks.landmark[LOWER_LIP],
        frame_width,
        frame_height
    )

    return distance(upper, lower)


# -------------------------------------------------------
# Eye Distance
# -------------------------------------------------------

def eye_distance(face_landmarks, frame_width, frame_height):

    left = landmark_to_pixel(
        face_landmarks.landmark[LEFT_EYE_CENTER],
        frame_width,
        frame_height
    )

    right = landmark_to_pixel(
        face_landmarks.landmark[RIGHT_EYE_CENTER],
        frame_width,
        frame_height
    )

    return distance(left, right)


# -------------------------------------------------------
# Mouth Width
# -------------------------------------------------------

def mouth_width(face_landmarks, frame_width, frame_height):

    left = landmark_to_pixel(
        face_landmarks.landmark[LEFT_MOUTH],
        frame_width,
        frame_height
    )

    right = landmark_to_pixel(
        face_landmarks.landmark[RIGHT_MOUTH],
        frame_width,
        frame_height
    )

    return distance(left, right)


# -------------------------------------------------------
# Face Height
# -------------------------------------------------------

def face_height(face_landmarks, frame_width, frame_height):

    forehead = landmark_to_pixel(
        face_landmarks.landmark[FOREHEAD],
        frame_width,
        frame_height
    )

    chin = landmark_to_pixel(
        face_landmarks.landmark[CHIN],
        frame_width,
        frame_height
    )

    return distance(forehead, chin)


# -------------------------------------------------------
# Face Width
# -------------------------------------------------------

def face_width(face_landmarks, frame_width, frame_height):

    left = landmark_to_pixel(
        face_landmarks.landmark[234],
        frame_width,
        frame_height
    )

    right = landmark_to_pixel(
        face_landmarks.landmark[454],
        frame_width,
        frame_height
    )

    return distance(left, right)


# -------------------------------------------------------
# Face Size
# -------------------------------------------------------

def face_size(face_landmarks, frame_width, frame_height):

    return {
        "width": face_width(face_landmarks, frame_width, frame_height),
        "height": face_height(face_landmarks, frame_width, frame_height)
    }


# -------------------------------------------------------
# Get Landmark
# -------------------------------------------------------

def get_landmark(face_landmarks,
                 landmark_id,
                 frame_width,
                 frame_height):

    return landmark_to_pixel(
        face_landmarks.landmark[landmark_id],
        frame_width,
        frame_height
    )


# -------------------------------------------------------
# Get All Landmarks
# -------------------------------------------------------

def get_all_landmarks(face_landmarks,
                      frame_width,
                      frame_height):

    points = []

    for lm in face_landmarks.landmark:

        points.append(
            landmark_to_pixel(
                lm,
                frame_width,
                frame_height
            )
        )

    return points


# -------------------------------------------------------
# Angle Between Three Points
# -------------------------------------------------------

def angle(p1, p2, p3):

    a = np.array(p1)
    b = np.array(p2)
    c = np.array(p3)

    ba = a - b
    bc = c - b

    cosine = np.dot(ba, bc) / (
        np.linalg.norm(ba) *
        np.linalg.norm(bc)
    )

    cosine = np.clip(cosine, -1.0, 1.0)

    return np.degrees(np.arccos(cosine))


# -------------------------------------------------------
# Face Bounding Box
# -------------------------------------------------------

def bounding_box(face_landmarks,
                 frame_width,
                 frame_height):

    points = get_all_landmarks(
        face_landmarks,
        frame_width,
        frame_height
    )

    xs = [p[0] for p in points]
    ys = [p[1] for p in points]

    return (
        min(xs),
        min(ys),
        max(xs),
        max(ys)
    )