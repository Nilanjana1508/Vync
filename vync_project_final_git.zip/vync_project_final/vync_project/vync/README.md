# Vync

A semantic video conferencing frontend, built to run fully offline today and
plug into a FastAPI AI server later.

## Running it

```bash
npm install
npm start
```

Opens at `http://localhost:3000`. You'll land on the login/signup screen
first - create an account, then you're in. Camera/mic access requires
`localhost` or HTTPS, both of which work fine in dev.

No backend server is required to run this right now - see Authentication
below.

## Pages

- **Login** (`/login`) / **Signup** (`/signup`) — account creation and
  sign-in. Currently a frontend-only placeholder (see Authentication
  below). Required before reaching anything else.
- **Dashboard** (`/`) — entry point, quick links, connection status.
- **New Meeting** (`/create`) — generates a shareable room code.
- **Join Meeting** (`/join`) — room code, AI server URL (validated).
- **Meeting Preview** (`/preview`) — live camera/mic check, device picker.
  Works with zero AI backend.
- **Meeting Room** (`/room`) — local video tile, remote placeholder tile,
  chat, participants, control bar.
- **Calendar**, **Chat**, **Contacts** — local-state utility pages.

## Authentication

**This is currently a frontend-only placeholder, not real authentication.**
A teammate's FastAPI server (which will eventually own real accounts in a
SQLite database) isn't built yet, so for now:

- `src/services/localAuth.js` stores accounts in this browser's
  `localStorage` instead of calling a server. Passwords are **not**
  hashed and **not** sent anywhere - this is enough to gate navigation
  during frontend development, but it is not security. Don't reuse a
  real password when signing up here.
- Accounts only exist on the browser/device that created them - signing
  up on one machine doesn't create an account anyone else can log into.
- Validation rules (user ID 4-20 chars, letters/numbers/underscore;
  password 8-64 chars with a letter and a number) live in
  `src/utils/authValidation.js`.
- Every route except `/login` and `/signup` is gated behind a valid
  session (`src/components/RequireAuth.jsx`).

**Swapping in the real backend later:** `src/context/AuthContext.jsx`
calls `signup()`, `login()`, and `fetchCurrentUser()` from
`src/services/localAuth.js`. A real API client just needs to export
those same three functions with the same signatures (see the comments
in `localAuth.js`) and get imported in `AuthContext.jsx` instead - the
rest of the app (Login/Signup pages, RequireAuth, TopBar) doesn't need
to change.

## How the AI backend will plug in (separate from auth)

- `src/services/websocket.js` opens a single socket to the AI server URL
  set on the Join page and exposes `sendMessage`, `sendAudioPacket`,
  `sendSemanticPacket`, plus handler registration for inbound packets.
- Packet shapes already match the documented future contract
  (`message`, `audio`, `semantic`). Until that server exists, the room
  just runs on local media and shows "Disconnected" / "AI Server Offline".
- `src/services/media.js` is the only place that touches
  `navigator.mediaDevices` — camera/mic start, stop, toggle, and device
  switching all live there.
- `src/context/MeetingContext.jsx` holds shared meeting state (room
  identity, connection status, media toggles, device selection,
  participants, messages) so pages stay thin.
- `src/utils/roomCode.js` is the single source of truth for room code
  format (10 letters, displayed/typed as `xxx-xxxx-xxx`) - generation,
  validation, and live input formatting all share this one rule, so a
  code generated on Create Meeting and a code typed on Join Meeting are
  never out of sync with each other.

## Notes

- No AI inference happens in this app. Audio/semantic packet senders
  exist with the right shape but placeholder payloads until the AI
  server side is ready.
- Remote video tile is a placeholder by design — it's where the
  AI-generated stream will render once LivePortrait/MuseTalk are wired
  up server-side.
