import React from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { MeetingProvider } from "./context/MeetingContext";
import { AuthProvider } from "./context/AuthContext";
import RequireAuth from "./components/RequireAuth";
import Login from "./pages/Login";
import Signup from "./pages/Signup";
import Dashboard from "./pages/Dashboard";
import JoinMeeting from "./pages/JoinMeeting";
import CreateMeeting from "./pages/CreateMeeting";
import MeetingPreview from "./pages/MeetingPreview";
import MeetingRoom from "./pages/MeetingRoom";
import Calendar from "./pages/Calendar";
import Chat from "./pages/Chat";
import Contacts from "./pages/Contacts";
import "./theme.css";
import "./App.css";

function App() {
  return (
    <AuthProvider>
      <MeetingProvider>
        <BrowserRouter>
          <Routes>
            <Route path="/login" element={<Login />} />
            <Route path="/signup" element={<Signup />} />

            <Route path="/" element={<RequireAuth><Dashboard /></RequireAuth>} />
            <Route path="/join" element={<RequireAuth><JoinMeeting /></RequireAuth>} />
            <Route path="/create" element={<RequireAuth><CreateMeeting /></RequireAuth>} />
            <Route path="/preview" element={<RequireAuth><MeetingPreview /></RequireAuth>} />
            <Route path="/room" element={<RequireAuth><MeetingRoom /></RequireAuth>} />
            <Route path="/calendar" element={<RequireAuth><Calendar /></RequireAuth>} />
            <Route path="/chat" element={<RequireAuth><Chat /></RequireAuth>} />
            <Route path="/contacts" element={<RequireAuth><Contacts /></RequireAuth>} />
          </Routes>
        </BrowserRouter>
      </MeetingProvider>
    </AuthProvider>
  );
}

export default App;
