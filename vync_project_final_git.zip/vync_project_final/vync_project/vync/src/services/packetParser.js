// services/packetParser.js
// Parses all inbound packets from the FastAPI server and semanxx local bridge
// into typed objects.  No UI logic here.  Unknown types pass through as { type, raw }.

export function parse(raw) {
  if (!raw || typeof raw !== "object") return { type: "unknown", raw };
  const t = raw.type || raw.packet_type;

  switch (t) {
    case "join_success":
      return { type: "join_success", roomId: raw.room_id, userId: raw.user_id };

    case "registration_ack":
      return { type: "registration_ack", registrationId: raw.payload?.registration_id };

    case "registration_nack":
      return {
        type:           "registration_nack",
        registrationId: raw.payload?.registration_id,
        missingIds:     raw.payload?.missing_ids || [],
      };

    // ── semanxx active-speaker result ──────────────────────────────────────
    // Arrives from:
    //   a) localBridge (localhost:8765) — direct semanxx broadcast
    //   b) FastAPI AI server — forwarded after processing
    //
    // Shape: {
    //   type:          "speaker_update",
    //   speaker_id:    "P001" | null,
    //   confidence:    0.87,
    //   semantic_data: { timestamp, people: [...], active_speaker: "P001" }
    // }
    case "speaker_update":
      return {
        type:         "speaker_update",
        speakerId:    raw.speaker_id    || null,
        confidence:   raw.confidence    ?? null,
        semanticData: raw.semantic_data || null,
      };

    // ── AI-generated talking-face video stream ─────────────────────────────
    // Sent by the FastAPI server once MuseTalk / LivePortrait is wired up.
    // Shape: {
    //   type:       "video_frame",
    //   speaker_id: "SP101",
    //   frame_data: "<base64 JPEG>",
    //   timestamp:  <ISO string>,
    // }
    case "video_frame":
      return {
        type:      "video_frame",
        speakerId: raw.speaker_id  || null,
        frameData: raw.frame_data  || null,
        timestamp: raw.timestamp   || null,
      };

    case "pong":
      return { type: "pong", serverTimestamp: raw.payload?.server_timestamp || null };

    case "error":
      return {
        type:    "error",
        code:    raw.payload?.code    || "UNKNOWN",
        message: raw.payload?.message || "Server error",
      };

    case "leave":
      return { type: "leave", reason: raw.payload?.reason || "Remote disconnected" };

    case "message":
      return { type: "message", raw };

    default:
      return { type: t || "unknown", raw };
  }
}
