// services/packetBuilder.js
// Single source of truth for all outbound packet construction.
// Sequence numbers tracked per (speakerId, packetType) pair.

const _counters = {};

function _seq(speakerId, packetType) {
  const key = `${speakerId || "global"}:${packetType}`;
  _counters[key] = (_counters[key] || 0) + 1;
  return _counters[key];
}

function _ts() {
  return new Date().toISOString();
}

function _base({ sessionId, roomId, nodeId = 1, speakerId = null, packetType, priority, payload }) {
  const packet = {
    session_id:      sessionId,
    room_id:         roomId,
    node_id:         nodeId,
    speaker_id:      speakerId,
    packet_type:     packetType,
    sequence_number: _seq(speakerId, packetType),
    timestamp:       _ts(),
    priority,
    payload,
  };
  console.log(`[packetBuilder] ▶ ${packetType} seq=${packet.sequence_number} speaker=${speakerId || "—"}`, packet);
  return packet;
}

export function buildJoinPacket({ sessionId, roomId, nodeId, displayName }) {
  return _base({ sessionId, roomId, nodeId, packetType: "join", priority: 2,
    payload: { display_name: displayName, client_version: "1.0.0" } });
}

export function buildLeavePacket({ sessionId, roomId, nodeId, reason = "User left" }) {
  return _base({ sessionId, roomId, nodeId, packetType: "leave", priority: 1,
    payload: { reason } });
}

export function buildPingPacket({ sessionId, roomId, nodeId }) {
  return _base({ sessionId, roomId, nodeId, packetType: "ping", priority: 3, payload: null });
}

export function buildRegistrationStartPacket({ sessionId, roomId, nodeId, registrationId, totalSnapshots }) {
  return _base({ sessionId, roomId, nodeId, packetType: "registration_start", priority: 1,
    payload: { registration_id: registrationId, total_snapshots: totalSnapshots } });
}

// faceId must match SP\d+ — SP101, SP102 etc.
// imageData: base64 PNG string
export function buildSnapshotPacket({ sessionId, roomId, nodeId, faceId, imageData, width = 512, height = 512 }) {
  return _base({ sessionId, roomId, nodeId, packetType: "snapshot", priority: 1,
    payload: { face_id: faceId, image_format: "png",
      image_width: width, image_height: height,
      embedding_available: false, image_data: imageData } });
}

export function buildRegistrationCompletePacket({ sessionId, roomId, nodeId, registrationId, registeredFaces }) {
  return _base({ sessionId, roomId, nodeId, packetType: "registration_complete", priority: 1,
    payload: { registration_id: registrationId, registered_faces: registeredFaces } });
}

// speakerId: SP101 — face ID of current speaker (from semanxx via server)
// audioData: base64 encoded audio bytes
// Sequence number is independent per speakerId+packetType pair
export function buildAudioPacket({ sessionId, roomId, nodeId, speakerId, audioData = null, codec = "opus", sampleRate = 16000, durationMs = 20 }) {
  return _base({ sessionId, roomId, nodeId, speakerId, packetType: "audio", priority: 2,
    payload: { codec, sample_rate: sampleRate, channels: 1, duration_ms: durationMs, audio_data: audioData } });
}

// semanxx produces all values below — React only packages them
// emotion + emotion_confidence always null (AI server fills these)
export function buildSemanticPacket({
  sessionId, roomId, nodeId, speakerId,
  landmarks = [], headPose = { yaw: 0, pitch: 0, roll: 0 },
  expression = { smile: 0, mouth_open: 0, eyebrow_raise: 0, blink_left: 0, blink_right: 0 },
  isSpeaking = false, mouthOpenRatio = 0,
  leftEyeOpen = 1, rightEyeOpen = 1,
  trackingConfidence = 0, visibilityScore = 1,
}) {
  return _base({ sessionId, roomId, nodeId, speakerId, packetType: "semantic", priority: 2,
    payload: {
      landmarks, head_pose: headPose, expression,
      emotion: null, emotion_confidence: null,
      is_speaking: isSpeaking, mouth_open_ratio: mouthOpenRatio,
      left_eye_open: leftEyeOpen, right_eye_open: rightEyeOpen,
      tracking_confidence: trackingConfidence, visibility_score: visibilityScore,
    } });
}
