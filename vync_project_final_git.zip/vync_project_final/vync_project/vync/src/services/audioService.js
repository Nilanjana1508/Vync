// services/audioService.js
// Captures microphone audio via MediaRecorder and sends audio packets
// stamped with the current speaker face ID (provided by semanxx via server).
//
// Codec: OPUS preferred, PCM fallback.
// Chunk: 20ms default.
// Speaker ID: updated live via setSpeaker() whenever speaker_update arrives.
// Sequence numbers: independent per speakerId (handled by packetBuilder).

import * as ws from "./websocket";
import { buildAudioPacket } from "./packetBuilder";

let _recorder       = null;
let _sessionId      = null;
let _roomId         = null;
let _nodeId         = 1;
let _currentSpeaker = null;   // current SP face ID (SP101 etc)
let _running        = false;

function _bestMime() {
  const candidates = [
    "audio/webm;codecs=opus",
    "audio/ogg;codecs=opus",
    "audio/webm",
    "audio/ogg",
  ];
  return candidates.find(m => MediaRecorder.isTypeSupported(m)) || "";
}

function _codec(mime) {
  if (mime.includes("opus")) return "opus";
  if (mime.includes("ogg"))  return "ogg";
  return "pcm";
}

export function start({ stream, sessionId, roomId, nodeId = 1, chunkMs = 20 }) {
  if (_running) stop();
  _sessionId = sessionId;
  _roomId    = roomId;
  _nodeId    = nodeId;
  _running   = true;

  const mime  = _bestMime();
  const codec = _codec(mime);

  try {
    _recorder = new MediaRecorder(stream, mime ? { mimeType: mime } : undefined);
  } catch (err) {
    console.warn("[audioService] MediaRecorder init failed", err);
    _running = false;
    return;
  }

  _recorder.ondataavailable = async (event) => {
    if (!event.data || event.data.size === 0) return;
    const buffer = await event.data.arrayBuffer();
    const bytes  = new Uint8Array(buffer);
    const base64 = btoa(String.fromCharCode(...bytes));

    ws.sendPacket(buildAudioPacket({
      sessionId: _sessionId,
      roomId:    _roomId,
      nodeId:    _nodeId,
      speakerId: _currentSpeaker,  // SP101 — null until speaker_update arrives
      audioData: base64,
      codec,
      sampleRate: 16000,
      durationMs: chunkMs,
    }));
  };

  _recorder.start(chunkMs);
}

// Call this whenever a speaker_update packet arrives.
// All subsequent audio chunks will be stamped with this face ID.
export function setSpeaker(speakerId) {
  _currentSpeaker = speakerId;
}

export function stop() {
  if (_recorder && _recorder.state !== "inactive") _recorder.stop();
  _recorder       = null;
  _running        = false;
  _currentSpeaker = null;
}

export function isRunning() { return _running; }
