// services/websocket.js
// Manages the single WebSocket connection to the FastAPI AI server.
// Packet construction is handled by packetBuilder.js — this module only
// manages the socket lifecycle, raw sendPacket, and handler registration.

import { WS_URL } from "../config/server";

let socket = null;
let messageHandlers = [];
let connectionHandlers = [];
let sequenceCounter = 0;

function nextSequence() {
  sequenceCounter += 1;
  return sequenceCounter;
}

function notifyConnectionHandlers(status) {
  connectionHandlers.forEach((handler) => {
    try {
      handler(status);
    } catch (err) {
      // A misbehaving handler should never break the socket lifecycle.
      console.error("connection handler error", err);
    }
  });
}

function notifyMessageHandlers(packet) {
  messageHandlers.forEach((handler) => {
    try {
      handler(packet);
    } catch (err) {
      console.error("message handler error", err);
    }
  });
}

/**
 * Opens a WebSocket connection to the given AI server URL.
 * Resolves once the socket reports "open"; rejects on immediate error.
 * @param {string} serverUrl - e.g. ws://192.168.1.15:8000/ws
 * @returns {Promise<WebSocket>}
 */
export function connect(serverUrl = WS_URL) {
  return new Promise((resolve, reject) => {
    try {
      disconnect();

      notifyConnectionHandlers("connecting");
      socket = new WebSocket(serverUrl);

      socket.onopen = () => {
        notifyConnectionHandlers("connected");
        resolve(socket);
      };

      socket.onmessage = (event) => {
        let packet;
        try {
          packet = JSON.parse(event.data);
        } catch (err) {
          // Non-JSON payloads are ignored rather than crashing the handler chain.
          console.warn("Received non-JSON packet, ignoring", event.data);
          return;
        }
        console.log(`[websocket] 📥 RECEIVED ← ${packet.type || packet.packet_type || "unknown"}`, packet);
        notifyMessageHandlers(packet);
      };

      socket.onclose = () => {
        notifyConnectionHandlers("disconnected");
        socket = null;
      };

      socket.onerror = (err) => {
        notifyConnectionHandlers("disconnected");
        reject(err);
      };
    } catch (err) {
      notifyConnectionHandlers("disconnected");
      reject(err);
    }
  });
}

/**
 * Closes the active WebSocket connection, if any.
 */
export function disconnect() {
  if (socket) {
    socket.onopen = null;
    socket.onmessage = null;
    socket.onclose = null;
    socket.onerror = null;
    socket.close();
    socket = null;
  }
}

/**
 * Returns true if the socket is currently open.
 */
export function isConnected() {
  return Boolean(socket) && socket.readyState === WebSocket.OPEN;
}

/**
 * Sends a raw packet object over the socket as JSON.
 * Safe to call even if disconnected; it will simply no-op.
 * @param {object} packet
 */
export function sendPacket(packet) {
  if (!isConnected()) {
    console.warn("[websocket] sendPacket DROPPED (not connected):", packet.packet_type || packet.type, packet);
    return false;
  }
  console.log(`[websocket] 📤 SENT → ${packet.packet_type || packet.type} seq=${packet.sequence_number || "—"} speaker=${packet.speaker_id || "—"}`);
  socket.send(JSON.stringify(packet));
  return true;
}

/**
 * Sends a chat message packet.
 * Shape: { type: "message", from, text, timestamp }
 * @param {string} from
 * @param {string} text
 */
export function sendMessage(from, text) {
  const packet = {
    type: "message",
    from,
    text,
    timestamp: Date.now(),
  };
  return sendPacket(packet);
}

/**
 * Sends an audio packet. The actual encoded payload is left as a
 * placeholder - the server side audio pipeline (synchronization,
 * resampling, forwarding) does not exist yet. The sequence number
 * is real and increments per call so ordering can be validated
 * once the backend is wired up.
 * Shape: { type: "audio", seq, payload }
 * @param {*} payload - placeholder for encoded audio data
 */
export function sendAudioPacket(payload = null) {
  const packet = {
    type: "audio",
    seq: nextSequence(),
    payload, // TODO(backend): encoded audio frame
  };
  return sendPacket(packet);
}

/**
 * Sends a semantic packet (emotion + head pose, eventually driven by
 * the AI server's face/expression analysis). Placeholder values are
 * sent until the real pipeline exists, but the shape matches the
 * documented future contract.
 * Shape: { type: "semantic", seq, emotion, head_pose }
 * @param {{emotion?: string, head_pose?: number[]}} data
 */
export function sendSemanticPacket(data = {}) {
  const packet = {
    type: "semantic",
    seq: nextSequence(),
    emotion: data.emotion || "neutral", // TODO(backend): real emotion classification
    head_pose: data.head_pose || [0, 0, 0], // TODO(backend): real head pose estimation
  };
  return sendPacket(packet);
}

/**
 * Registers a handler invoked for every inbound packet.
 * Returns an unsubscribe function.
 * @param {(packet: object) => void} handler
 */
export function registerMessageHandler(handler) {
  messageHandlers.push(handler);
  return () => {
    messageHandlers = messageHandlers.filter((h) => h !== handler);
  };
}

/**
 * Registers a handler invoked whenever connection status changes.
 * Status is one of "connecting" | "connected" | "disconnected".
 * Returns an unsubscribe function.
 * @param {(status: string) => void} handler
 */
export function registerConnectionHandler(handler) {
  connectionHandlers.push(handler);
  return () => {
    connectionHandlers = connectionHandlers.filter((h) => h !== handler);
  };
}

/**
 * Clears all registered handlers. Useful on full app teardown / tests.
 */
export function clearHandlers() {
  messageHandlers = [];
  connectionHandlers = [];
}
