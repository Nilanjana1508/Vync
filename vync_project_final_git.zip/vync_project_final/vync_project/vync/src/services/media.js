// services/media.js
// Wraps the browser MediaDevices API so components don't talk to
// navigator.mediaDevices directly. All functions are plain async
// functions - no React here, so this can be reused or unit tested
// independently of the UI layer.

let activeStream = null;

/**
 * Requests a camera + microphone stream and stores it as the active stream.
 * @param {object} options - optional deviceId overrides
 * @param {string} [options.cameraId]
 * @param {string} [options.microphoneId]
 * @returns {Promise<MediaStream>}
 */
export async function startCamera(options = {}) {
  const { cameraId, microphoneId } = options;

  const constraints = {
    video: cameraId
      ? { deviceId: { exact: cameraId } }
      : { width: { ideal: 1280 }, height: { ideal: 720 } },
    audio: microphoneId ? { deviceId: { exact: microphoneId } } : true,
  };

  // Stop any existing stream first so we don't leak camera/mic handles.
  stopCamera();

  const stream = await navigator.mediaDevices.getUserMedia(constraints);
  activeStream = stream;
  return stream;
}

/**
 * Stops all tracks on the currently active stream, releasing camera/mic.
 */
export function stopCamera() {
  if (activeStream) {
    activeStream.getTracks().forEach((track) => track.stop());
    activeStream = null;
  }
}

/**
 * Returns the currently active MediaStream, if any.
 */
export function getActiveStream() {
  return activeStream;
}

/**
 * Enables or disables the microphone track in place, without
 * tearing down the whole stream.
 * @param {boolean} enabled
 */
export function toggleMic(enabled) {
  if (!activeStream) return;
  activeStream.getAudioTracks().forEach((track) => {
    track.enabled = enabled;
  });
}

/**
 * Turns the camera fully on or off.
 *
 * Unlike toggleMic, this does NOT just set track.enabled = false.
 * Setting `enabled` on a video track stops it from producing frames,
 * but the underlying hardware capture stays active, which is why the
 * physical camera light on most laptops stays on even after "turning
 * the camera off" in many video call apps. To actually release the
 * hardware (and turn that light off), the video track must be
 * stop()'d and removed. When turning the camera back on, a fresh
 * video track is requested and swapped back into the existing
 * stream, leaving the audio track untouched.
 *
 * @param {boolean} enabled
 * @param {string|null} [deviceId] - camera device to use when turning back on
 * @returns {Promise<MediaStream|null>} the active stream after the change
 */
export async function toggleCamera(enabled, deviceId = null) {
  if (!activeStream) return null;

  if (!enabled) {
    // Turning camera OFF: stop and remove the video track so the
    // hardware is actually released and the camera light turns off.
    activeStream.getVideoTracks().forEach((track) => {
      activeStream.removeTrack(track);
      track.stop();
    });
    return activeStream;
  }

  // Turning camera ON: request a new video track and attach it.
  const constraints = deviceId
    ? { video: { deviceId: { exact: deviceId } } }
    : { video: { width: { ideal: 1280 }, height: { ideal: 720 } } };

  const newVideoStream = await navigator.mediaDevices.getUserMedia(
    constraints
  );
  const newVideoTrack = newVideoStream.getVideoTracks()[0];
  activeStream.addTrack(newVideoTrack);
  return activeStream;
}

/**
 * Lists available input devices, split into cameras and microphones.
 * Device labels are only populated by the browser once permission has
 * been granted at least once, so callers should call startCamera()
 * before relying on labels.
 * @returns {Promise<{cameras: MediaDeviceInfo[], microphones: MediaDeviceInfo[]}>}
 */
export async function getDevices() {
  const allDevices = await navigator.mediaDevices.enumerateDevices();
  const cameras = allDevices.filter((d) => d.kind === "videoinput");
  const microphones = allDevices.filter((d) => d.kind === "audioinput");
  return { cameras, microphones };
}

/**
 * Switches the active stream's video track to a different camera device.
 * Replaces the video track in place; keeps the audio track untouched.
 * @param {string} deviceId
 * @returns {Promise<MediaStream>}
 */
export async function switchCamera(deviceId) {
  const newVideoStream = await navigator.mediaDevices.getUserMedia({
    video: { deviceId: { exact: deviceId } },
  });
  const newVideoTrack = newVideoStream.getVideoTracks()[0];

  if (activeStream) {
    const oldVideoTracks = activeStream.getVideoTracks();
    oldVideoTracks.forEach((track) => {
      activeStream.removeTrack(track);
      track.stop();
    });
    activeStream.addTrack(newVideoTrack);
  } else {
    activeStream = newVideoStream;
  }

  return activeStream;
}

/**
 * Switches the active stream's audio track to a different microphone device.
 * Replaces the audio track in place; keeps the video track untouched.
 * @param {string} deviceId
 * @returns {Promise<MediaStream>}
 */
export async function switchMicrophone(deviceId) {
  const newAudioStream = await navigator.mediaDevices.getUserMedia({
    audio: { deviceId: { exact: deviceId } },
  });
  const newAudioTrack = newAudioStream.getAudioTracks()[0];

  if (activeStream) {
    const oldAudioTracks = activeStream.getAudioTracks();
    oldAudioTracks.forEach((track) => {
      activeStream.removeTrack(track);
      track.stop();
    });
    activeStream.addTrack(newAudioTrack);
  } else {
    activeStream = newAudioStream;
  }

  return activeStream;
}

/**
 * Checks whether the browser supports the APIs Vync depends on.
 * @returns {boolean}
 */
export function isMediaSupported() {
  return Boolean(
    navigator.mediaDevices && navigator.mediaDevices.getUserMedia
  );
}

/**
 * Directly sets the active stream reference.
 * Used when MeetingRoom/MeetingPreview open a mic-only stream and need
 * to make it available to audioService without going through startCamera().
 * @param {MediaStream} stream
 */
export function _setActiveStream(stream) {
  activeStream = stream;
}
