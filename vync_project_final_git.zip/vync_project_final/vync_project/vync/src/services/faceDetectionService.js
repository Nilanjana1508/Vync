// services/faceDetectionService.js
// Maintains stable SP-prefixed face IDs mapped from semanxx person IDs (P001→SP101).
// Does NOT run any AI — IDs arrive from the server's speaker_update packets.
// Camera toggle must NEVER re-trigger registration for already-seen faces.

const _registry    = new Map();  // personId (P001) → faceId (SP101)
const _registered  = new Set();  // faceIds that completed registration this session
let   _counter     = 100;

// Assign a stable SP face ID for a semanxx person ID. Creates one on first encounter.
export function getOrAssignFaceId(personId) {
  if (!personId) return null;
  if (!_registry.has(personId)) {
    _counter += 1;
    _registry.set(personId, `SP${_counter}`);
  }
  return _registry.get(personId);
}

// True if this SP face ID has already been registered this session.
export function isRegistered(faceId) {
  return _registered.has(faceId);
}

// Called by registrationService after ACK is received.
export function markRegistered(faceId) {
  _registered.add(faceId);
}

// Returns all SP face IDs not yet registered — these need snapshot packets.
export function getUnregisteredFaceIds() {
  return Array.from(_registry.values()).filter(id => !_registered.has(id));
}

// Returns the reverse mapping: SP101 → P001 (useful for logging)
export function getPersonId(faceId) {
  for (const [pid, fid] of _registry.entries()) {
    if (fid === faceId) return pid;
  }
  return null;
}

// Clear all state on session end.
export function reset() {
  _registry.clear();
  _registered.clear();
  _counter = 100;
}
