// services/localBridge.js
// Connects to semanxx's local WebSocket server on localhost:8765.
//
// semanxx sends three frame types over this connection:
//
//   TEXT   frame → JSON speaker_update packet
//                  { type, speaker_id, confidence, semantic_data }
//                  → routed to queueManager → MeetingRoom handlers
//
//   BINARY frame → byte[0] == 0x00  (audio)
//                  Remaining bytes: compressed PCM (ADPCM/MP3/OGG/μ-law)
//                  → localAudioPlayer → Web Audio API
//
//   BINARY frame → byte[0] == 0x01  (video)
//                  Remaining bytes: JPEG camera frame from semanxx
//                  → localVideoReceiver → local tile <canvas>
//
// This means React never calls getUserMedia() for camera/mic —
// semanxx owns those devices exclusively, preventing the conflict.
//
// semanxx must be running (python main.py) before this connects.
// If not running, the bridge retries every 3 s silently.

import { parse } from "./packetParser";
import * as queueManager from "./queueManager";
import * as localAudioPlayer from "./localAudioPlayer";
import * as localVideoReceiver from "./localVideoReceiver";

const LOCAL_URL   = "ws://localhost:8765";
const RETRY_DELAY = 3000;

// Binary frame type markers — must match main.py constants
const FRAME_TYPE_AUDIO = 0x00;
const FRAME_TYPE_VIDEO = 0x01;

let _socket     = null;
let _running    = false;
let _retryTimer = null;
let _onStatus   = null;

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

/**
 * Start the local bridge.
 * @param {{ onStatus?: (status: string) => void }} opts
 */
export function start({ onStatus } = {}) {
  if (_running) return;
  _running  = true;
  _onStatus = onStatus || null;
  _connect();
}

export function stop() {
  _running = false;
  if (_retryTimer) { clearTimeout(_retryTimer); _retryTimer = null; }
  if (_socket)     { _socket.onclose = null; _socket.close(); _socket = null; }
  localAudioPlayer.stop();
  _onStatus?.("disconnected");
}

export function isConnected() {
  return Boolean(_socket) && _socket.readyState === WebSocket.OPEN;
}

// ---------------------------------------------------------------------------
// Internal
// ---------------------------------------------------------------------------

function _connect() {
  if (!_running) return;

  try {
    _socket = new WebSocket(LOCAL_URL);
    _socket.binaryType = "arraybuffer";
  } catch {
    _scheduleRetry();
    return;
  }

  _socket.onopen = () => {
    console.log("[localBridge] ✅ Connected to semanxx on", LOCAL_URL);
    _onStatus?.("connected");
    localAudioPlayer.start();
  };

  _socket.onmessage = (event) => {
    // ── Binary frame ─────────────────────────────────────────────────────
    if (event.data instanceof ArrayBuffer) {
      const bytes   = new Uint8Array(event.data);
      const type    = bytes[0];
      const payload = bytes.subarray(1);

      if (type === FRAME_TYPE_VIDEO) {
        // JPEG camera frame from semanxx → paint onto local tile canvas
        localVideoReceiver.receiveFrame(payload);
      } else {
        // FRAME_TYPE_AUDIO — compressed PCM → play through Web Audio API
        localAudioPlayer.receiveChunk(payload);
      }
      return;
    }

    // ── Text frame → JSON semantic / speaker_update ───────────────────────
    let raw;
    try { raw = JSON.parse(event.data); }
    catch {
      console.warn("[localBridge] Non-JSON from semanxx:", event.data);
      return;
    }

    const packet = parse(raw);
    console.log(
      `[localBridge] 📨 semanxx — speaker: ${packet.speakerId || "none"} ` +
      `confidence: ${packet.confidence ?? "—"}`
    );
    queueManager.enqueue(packet);
  };

  _socket.onclose = () => {
    _socket = null;
    console.log("[localBridge] Disconnected from semanxx — retrying in 3 s");
    _onStatus?.("disconnected");
    localAudioPlayer.stop();
    _scheduleRetry();
  };

  _socket.onerror = () => {
    // onerror is always followed by onclose — retry handled there.
  };
}

function _scheduleRetry() {
  if (!_running) return;
  _retryTimer = setTimeout(() => {
    _retryTimer = null;
    _connect();
  }, RETRY_DELAY);
}
