// services/queueManager.js
// Lightweight per-type playback buffer for inbound packets.
// Does NOT do AI sync, reordering, or any server-side logic.
// Packets drain to registered handlers immediately; buffered if no handler yet.

const _queues   = {};
const _handlers = {};

export function enqueue(packet) {
  const t = packet.type;
  if (!_queues[t]) _queues[t] = [];
  _queues[t].push(packet);
  if (_handlers[t]) _drain(t);
}

// Register a handler for a packet type. Returns unsubscribe function.
export function onPacket(type, handler) {
  _handlers[type] = handler;
  _drain(type);
  return () => { delete _handlers[type]; };
}

function _drain(type) {
  const q = _queues[type];
  if (!q || q.length === 0 || !_handlers[type]) return;
  while (q.length > 0) {
    try { _handlers[type](q.shift()); }
    catch (err) { console.error("[queueManager] handler error", err); }
  }
}

export function reset() {
  Object.keys(_queues).forEach(k => delete _queues[k]);
  Object.keys(_handlers).forEach(k => delete _handlers[k]);
}
