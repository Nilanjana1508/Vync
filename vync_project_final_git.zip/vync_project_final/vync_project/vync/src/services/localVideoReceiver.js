// services/localVideoReceiver.js
// Receives JPEG video frames from semanxx over the local bridge and
// paints them onto a <canvas> element used as the local tile in MeetingRoom.
//
// Why a canvas instead of getUserMedia():
//   semanxx holds the camera via cv2.VideoCapture(0). The browser cannot
//   open the same device simultaneously. Instead of fighting over the camera,
//   semanxx encodes each processed frame as JPEG and sends it here as a
//   binary WebSocket frame (type marker 0x01). React renders it on a canvas
//   — the user sees the same annotated view that semanxx shows locally,
//   including face bounding boxes and speaker overlays.
//
// Usage:
//   attach(canvasElement)   — call once the canvas is mounted
//   receiveFrame(jpegBytes) — called by localBridge for every 0x01 frame
//   detach()                — call on cleanup

let _canvas  = null;
let _ctx     = null;
let _pending = null;   // latest ImageBitmap ready to paint
let _rafId   = null;

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

/**
 * Attach to a <canvas> DOM element. Must be called before frames arrive.
 * @param {HTMLCanvasElement} canvas
 */
export function attach(canvas) {
  _canvas = canvas;
  _ctx    = canvas.getContext("2d");
  _startLoop();
  console.log("[localVideoReceiver] ▶ attached to local canvas");
}

export function detach() {
  _stopLoop();
  if (_pending) { _pending.close(); _pending = null; }
  _canvas = null;
  _ctx    = null;
  console.log("[localVideoReceiver] ⏹ detached");
}

/**
 * Receive a raw JPEG byte array from localBridge (the 0x01 payload,
 * type byte already stripped). Decodes asynchronously and queues for paint.
 * @param {Uint8Array} jpegBytes
 */
export async function receiveFrame(jpegBytes) {
  if (!_canvas) return;
  try {
    const blob   = new Blob([jpegBytes], { type: "image/jpeg" });
    const bitmap = await createImageBitmap(blob);

    if (_pending) _pending.close();
    _pending = bitmap;
  } catch (err) {
    console.warn("[localVideoReceiver] JPEG decode error:", err);
  }
}

/** True once at least one frame has been received and painted. */
export function hasVideo() {
  return _pending !== null;
}

// ---------------------------------------------------------------------------
// RAF paint loop
// ---------------------------------------------------------------------------

function _startLoop() {
  if (_rafId !== null) return;

  function loop() {
    if (_ctx && _pending && _canvas) {
      _ctx.drawImage(_pending, 0, 0, _canvas.width, _canvas.height);
    }
    _rafId = requestAnimationFrame(loop);
  }

  _rafId = requestAnimationFrame(loop);
}

function _stopLoop() {
  if (_rafId !== null) {
    cancelAnimationFrame(_rafId);
    _rafId = null;
  }
}
