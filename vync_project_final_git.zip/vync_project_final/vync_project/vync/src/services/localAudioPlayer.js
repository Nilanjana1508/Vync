// services/localAudioPlayer.js
// Plays compressed audio chunks received from semanxx over the local bridge.
//
// semanxx sends binary WebSocket frames containing ADPCM-compressed PCM audio
// (16-bit signed mono, 16 kHz). We decode them in a Web Worker (to avoid
// blocking the main thread) and play them through the Web Audio API.
//
// Codec support matrix (matches audio_codec.py priority order):
//   1. MP3  — decode via AudioContext.decodeAudioData (native browser support)
//   2. OGG  — decode via AudioContext.decodeAudioData (Chrome/Firefox)
//   3. ADPCM — custom JS decoder (IMA ADPCM, 4-bit nibbles)
//   4. μ-law — custom JS decoder (8-bit μ-law, stdlib fallback)
//
// The codec is auto-detected per chunk from a 4-byte magic header prefix
// that semanxx prepends.  Raw ADPCM/μ-law chunks have no magic header, so
// they fall through to the last-resort decoders in order.
//
// A small jitter buffer (JITTER_BUFFER_SIZE chunks) absorbs network variance
// before playback starts, then drains at real-time pace.

const SAMPLE_RATE       = 16000;
const CHANNELS          = 1;
const JITTER_BUFFER_SIZE = 4;   // chunks to buffer before starting playback

let _audioCtx      = null;
let _buffer        = [];        // Uint8Array chunks waiting to play
let _nextPlayTime  = 0;         // AudioContext time for next chunk
let _running       = false;

// ---------------------------------------------------------------------------
// IMA ADPCM decoder (mirrors audio_codec.py exactly)
// ---------------------------------------------------------------------------

const STEP_TABLE = [
  7,8,9,10,11,12,13,14,16,17,19,21,23,25,28,31,34,37,41,45,
  50,55,60,66,73,80,88,97,107,118,130,143,157,173,190,209,230,
  253,279,307,337,371,408,449,494,544,598,658,724,796,876,963,
  1060,1166,1282,1411,1552,1707,1878,2066,2272,2499,2749,3024,3327,
  3660,4026,4428,4871,5358,5894,6484,7132,7845,8630,9493,10442,
  11487,12635,13899,15289,16818,18500,20350,22385,24623,27086,29794,32767,
];

const INDEX_TABLE = [-1,-1,-1,-1,2,4,6,8,-1,-1,-1,-1,2,4,6,8];

function _decodeAdpcm(bytes) {
  if (bytes.length < 4) return new Float32Array(0);

  const view = new DataView(bytes.buffer, bytes.byteOffset);
  let pred   = view.getInt16(0, true);
  let idx    = view.getInt16(2, true);
  const packed = bytes.subarray(4);

  const nibbles = [];
  for (const byte of packed) {
    nibbles.push(byte & 0x0F);
    nibbles.push((byte >> 4) & 0x0F);
  }

  const samples = new Float32Array(nibbles.length);
  for (let i = 0; i < nibbles.length; i++) {
    const code  = nibbles[i];
    const safeIdx = Math.max(0, Math.min(88, idx));
    const step  = STEP_TABLE[safeIdx];
    const sign  = code & 8;
    const code4 = code & 7;

    let delta = step >> 3;
    if (code4 & 4) delta += step;
    if (code4 & 2) delta += step >> 1;
    if (code4 & 1) delta += step >> 2;

    pred += sign ? -delta : delta;
    pred  = Math.max(-32768, Math.min(32767, pred));
    idx   = Math.max(0, Math.min(88, idx + INDEX_TABLE[code & 7]));
    samples[i] = pred / 32768.0;  // normalise to [-1, 1]
  }
  return samples;
}

// ---------------------------------------------------------------------------
// μ-law decoder (mirrors audio_codec.py)
// ---------------------------------------------------------------------------

function _decodeUlaw(bytes) {
  const samples = new Float32Array(bytes.length);
  for (let i = 0; i < bytes.length; i++) {
    let u  = ~bytes[i] & 0xFF;
    const sign = (u & 0x80) ? -1 : 1;
    const exp  = (u >> 4) & 0x07;
    const mant = u & 0x0F;
    const pcm  = sign * ((mant << (exp + 3)) + (33 << exp) - 33);
    samples[i] = Math.max(-1, Math.min(1, pcm / 32768.0));
  }
  return samples;
}

// ---------------------------------------------------------------------------
// Magic-byte detection
// ---------------------------------------------------------------------------

function _detectCodec(chunk) {
  if (chunk.length < 3) return "adpcm";
  // MP3 sync word: 0xFF 0xFB or 0xFF 0xF3 or 0xFF 0xE0-0xFF
  if (chunk[0] === 0xFF && (chunk[1] & 0xE0) === 0xE0) return "mp3";
  // OGG capture pattern: "OggS"
  if (chunk[0] === 0x4F && chunk[1] === 0x67 && chunk[2] === 0x67) return "ogg";
  // ADPCM: header is two int16 (pred, index). index must be 0-88.
  // Use as default — also covers μ-law if ADPCM decode produces garbage
  // (caller falls back by checking output length).
  return "adpcm";
}

// ---------------------------------------------------------------------------
// Decode a chunk to Float32Array samples
// ---------------------------------------------------------------------------

async function _decode(chunk) {
  const codec = _detectCodec(chunk);

  if ((codec === "mp3" || codec === "ogg") && _audioCtx) {
    try {
      const ab     = chunk.buffer.slice(chunk.byteOffset, chunk.byteOffset + chunk.length);
      const decoded = await _audioCtx.decodeAudioData(ab);
      // Return interleaved Float32 from channel 0 (mono)
      return decoded.getChannelData(0);
    } catch {
      // Fall through to ADPCM
    }
  }

  const adpcm = _decodeAdpcm(chunk);
  if (adpcm.length > 0) return adpcm;

  // Last resort: μ-law
  return _decodeUlaw(chunk);
}

// ---------------------------------------------------------------------------
// Schedule decoded samples on the AudioContext timeline
// ---------------------------------------------------------------------------

function _scheduleSamples(samples) {
  if (!_audioCtx || samples.length === 0) return;

  const audioBuffer = _audioCtx.createBuffer(CHANNELS, samples.length, SAMPLE_RATE);
  audioBuffer.copyToChannel(samples, 0);

  const source = _audioCtx.createBufferSource();
  source.buffer = audioBuffer;
  source.connect(_audioCtx.destination);

  // Clamp to current time so we never schedule in the past
  const when = Math.max(_audioCtx.currentTime, _nextPlayTime);
  source.start(when);
  _nextPlayTime = when + audioBuffer.duration;
}

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

export function start() {
  if (_running) return;
  _running = true;
  _buffer  = [];
  _nextPlayTime = 0;

  // AudioContext must be created (or resumed) from a user-gesture context.
  // MeetingRoom's handleJoin satisfies this; if context already exists, reuse.
  if (!_audioCtx) {
    _audioCtx = new (window.AudioContext || window.webkitAudioContext)({
      sampleRate: SAMPLE_RATE,
    });
  } else if (_audioCtx.state === "suspended") {
    _audioCtx.resume().catch(() => {});
  }

  console.log("[localAudioPlayer] ▶ started — waiting for semanxx audio chunks");
}

export function stop() {
  _running = false;
  _buffer  = [];
  // Don't close the AudioContext — it's expensive to recreate and the browser
  // limits how many can be created per page. Suspend instead.
  _audioCtx?.suspend().catch(() => {});
  console.log("[localAudioPlayer] ⏹ stopped");
}

/**
 * Called by localBridge for every binary frame arriving from semanxx.
 * Chunks are buffered until JITTER_BUFFER_SIZE is reached, then decoded
 * and scheduled on the audio timeline.
 *
 * @param {Uint8Array} chunk
 */
export async function receiveChunk(chunk) {
  if (!_running) return;

  _buffer.push(chunk);

  // Wait until the jitter buffer has enough chunks before playing.
  if (_buffer.length < JITTER_BUFFER_SIZE) return;

  // Drain one chunk at a time — decode + schedule
  const next = _buffer.shift();
  try {
    const samples = await _decode(next);
    _scheduleSamples(samples);
  } catch (err) {
    console.warn("[localAudioPlayer] decode error:", err);
  }
}
