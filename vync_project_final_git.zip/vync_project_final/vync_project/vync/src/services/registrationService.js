// services/registrationService.js
// Orchestrates the face registration phase immediately after JOIN succeeds.
//
// Protocol:
//   registration_start → N×snapshot → registration_complete → wait ACK/NACK
//   On NACK: retransmit ONLY the missing snapshots, then registration_complete again.
//   On ACK:  mark each face as registered so camera toggle won't re-trigger this.
//
// UI is never blocked — all work is async. Caller supplies onStatusChange for banner.

import * as ws from "./websocket";
import { buildRegistrationStartPacket, buildSnapshotPacket, buildRegistrationCompletePacket } from "./packetBuilder";
import { isRegistered, markRegistered } from "./faceDetectionService";

// Cache captured portraits for retransmission on NACK.
const _cache = new Map();  // faceId → base64 PNG string

// Capture a 512×512 portrait from the active video element.
function _capture() {
  try {
    const videoEl = document.querySelector("video");
    if (!videoEl || videoEl.readyState < 2) return "";
    const canvas = document.createElement("canvas");
    canvas.width  = 512;
    canvas.height = 512;
    canvas.getContext("2d").drawImage(videoEl, 0, 0, 512, 512);
    return canvas.toDataURL("image/png").split(",")[1];
  } catch {
    return "";
  }
}

// Run a full registration sequence for the given list of SP face IDs.
// Skips any face already registered this session.
export async function runRegistration({ sessionId, roomId, nodeId = 1, faceIds, onStatusChange }) {
  const toRegister = faceIds.filter(id => !isRegistered(id));
  if (toRegister.length === 0) return;

  onStatusChange?.("Registering participant...");

  const registrationId = `REG${Date.now()}`;
  console.log(`[registrationService] Starting registration for ${toRegister.length} face(s):`, toRegister);

  // Capture and cache portraits before sending anything
  for (const faceId of toRegister) {
    const imgData = _capture();
    _cache.set(faceId, imgData);
    console.log(`[registrationService] 📸 Snapshot captured for ${faceId} — size: ${imgData.length} chars (${imgData ? "OK" : "EMPTY — video not ready"})`);
  }

  // Send registration sequence
  console.log(`[registrationService] Sending registration_start (id=${registrationId}, total=${toRegister.length})`);
  ws.sendPacket(buildRegistrationStartPacket({
    sessionId, roomId, nodeId, registrationId, totalSnapshots: toRegister.length,
  }));

  for (const faceId of toRegister) {
    const imgData = _cache.get(faceId) || "";
    console.log(`[registrationService] Sending snapshot for ${faceId} — image_data length: ${imgData.length}`);
    ws.sendPacket(buildSnapshotPacket({
      sessionId, roomId, nodeId, faceId, imageData: imgData,
    }));
  }

  console.log(`[registrationService] Sending registration_complete`);
  ws.sendPacket(buildRegistrationCompletePacket({
    sessionId, roomId, nodeId, registrationId, registeredFaces: toRegister.length,
  }));
  console.log(`[registrationService] ✅ Registration sequence sent — waiting for ACK/NACK`);
}

// Handle ACK or NACK from server. Returns true if packet was consumed.
export function handleServerPacket({ packet, sessionId, roomId, nodeId = 1, registeredIds, onStatusChange }) {
  if (packet.type === "registration_ack") {
    console.log("[registrationService] ✅ ACK received — faces registered:", registeredIds);
    registeredIds.forEach(id => markRegistered(id));
    onStatusChange?.(null);
    return true;
  }

  if (packet.type === "registration_nack") {
    const missing = packet.missingIds || [];
    console.warn("[registrationService] ⚠️ NACK received — missing face IDs:", missing);
    onStatusChange?.(`Resending ${missing.length} snapshot(s)...`);

    // Retransmit ONLY what the server says it missed
    missing.forEach(faceId => {
      ws.sendPacket(buildSnapshotPacket({
        sessionId, roomId, nodeId, faceId, imageData: _cache.get(faceId) || "",
      }));
    });

    ws.sendPacket(buildRegistrationCompletePacket({
      sessionId, roomId, nodeId,
      registrationId: `REG${Date.now()}`,
      registeredFaces: missing.length,
    }));
    onStatusChange?.(null);
    return true;
  }

  return false;
}

export function reset() {
  _cache.clear();
}
