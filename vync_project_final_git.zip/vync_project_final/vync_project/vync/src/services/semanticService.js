// services/semanticService.js
// Sends semantic packets built from data produced by semanxx.
// React NEVER computes landmarks, head pose, or expression — it only
// packages the values arriving from semanxx (via the local bridge) and
// forwards them to FastAPI as properly-shaped protocol packets.
//
// semanxx semantic_data shape (from main.py → LocalBroadcaster):
// {
//   timestamp:      <float>,
//   people: [
//     {
//       id:                 "P001",
//       emotion:            "Happy",
//       emotion_confidence: 0.94,
//       head_pose: { yaw: 2.1, pitch: -1.4, roll: 0.8 },
//       speaker_score:      0.15,
//     },
//     ...
//   ],
//   active_speaker: "P001" | null,
// }

import * as ws from "./websocket";
import { buildSemanticPacket } from "./packetBuilder";

/**
 * Forward a semanxx-derived semantic packet to the FastAPI server.
 *
 * @param {{
 *   sessionId:          string,
 *   roomId:             string,
 *   nodeId:             number,
 *   speakerId:          string,       // SP-prefixed face ID (e.g. SP101)
 *   headPose:           { yaw: number, pitch: number, roll: number },
 *   landmarks:          number[][],   // 468×2 from FaceMesh (empty until server forwards)
 *   expression:         object,
 *   isSpeaking:         boolean,
 *   mouthOpenRatio:     number,
 *   trackingConfidence: number,       // maps to speaker_score from semanxx
 *   visibilityScore:    number,
 * }} data
 */
export function push(data) {
  ws.sendPacket(buildSemanticPacket(data));
}

/**
 * Convenience: extract and push semantic data for every person in a
 * semanxx semantic_data block, not just the active speaker.
 *
 * @param {{
 *   semanticData: object,   // full semanxx packet (people[], active_speaker)
 *   sessionId:    string,
 *   roomId:       string,
 *   nodeId:       number,
 *   getSpId:      (personId: string) => string,  // P001 → SP101
 * }} opts
 */
export function pushAll({ semanticData, sessionId, roomId, nodeId, getSpId }) {
  if (!semanticData?.people) return;

  const activePid = semanticData.active_speaker;

  for (const person of semanticData.people) {
    const spId = getSpId(person.id);
    if (!spId) continue;

    push({
      sessionId,
      roomId,
      nodeId,
      speakerId:          spId,
      headPose:           person.head_pose || { yaw: 0, pitch: 0, roll: 0 },
      landmarks:          [],
      expression:         {
        smile:         0,
        mouth_open:    0,
        eyebrow_raise: 0,
        blink_left:    0,
        blink_right:   0,
      },
      isSpeaking:         person.id === activePid,
      mouthOpenRatio:     0,
      trackingConfidence: person.speaker_score || 0,
      visibilityScore:    1,
    });
  }
}
