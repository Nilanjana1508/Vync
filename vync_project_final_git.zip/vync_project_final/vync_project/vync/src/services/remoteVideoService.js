// services/remoteVideoService.js
// Receives AI-generated talking-face video_frame packets from the FastAPI
// server and renders them onto a <canvas> element so MeetingRoom can display
// the reconstructed portrait without needing a MediaStream.
//
// Usage:
//   1. Call attach(canvasElement) in MeetingRoom once the canvas is mounted.
//   2. Feed incoming video_frame packets with push(packet).
//   3. Call detach() on cleanup.
//
// The canvas is updated with requestAnimationFrame so rendering is
// always synchronised with the browser paint cycle and never blocks the
// WebSocket message thread.

let _canvas   = null;
let _ctx2d    = null;
let _pending  = null;   // latest decoded ImageBitmap waiting to paint
let _rafId    = null;
let _onFrame  = null;   // optional (speakerId) => void callback

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

/**
 * Attach the service to a <canvas> DOM element.
 * @param {HTMLCanvasElement} canvas
 * @param {{ onFrame?: (speakerId: string) => void }} opts
 */
export function attach(canvas, { onFrame } = {}) {
  _canvas  = canvas;
  _ctx2d   = canvas.getContext("2d");
  _onFrame = onFrame || null;
  _startLoop();
  console.log("[remoteVideoService] ▶ attached to canvas");
}

export function detach() {
  _stopLoop();
  if (_pending) { _pending.close(); _pending = null; }
  _canvas  = null;
  _ctx2d   = null;
  _onFrame = null;
  console.log("[remoteVideoService] ⏹ detached");
}

/**
 * Receive a parsed video_frame packet from packetParser.
 * Decodes the base64 JPEG asynchronously and queues it for the paint loop.
 *
 * @param {{ speakerId: string|null, frameData: string|null }} packet
 */
export async function push(packet) {
  if (!packet.frameData || !_canvas) return;

  try {
    const blob   = _b64ToBlob(packet.frameData, "image/jpeg");
    const bitmap = await createImageBitmap(blob);

    // Discard the old pending frame (we only ever render the latest)
    if (_pending) _pending.close();
    _pending = bitmap;

    _onFrame?.(packet.speakerId);
  } catch (err) {
    console.warn("[remoteVideoService] frame decode error:", err);
  }
}

// ---------------------------------------------------------------------------
// Paint loop
// ---------------------------------------------------------------------------

function _startLoop() {
  if (_rafId !== null) return;

  function loop() {
    if (_ctx2d && _pending) {
      _ctx2d.drawImage(_pending, 0, 0, _canvas.width, _canvas.height);
      // Keep reference — will be overwritten by next push(), not closed here
      // so the canvas doesn't flicker between frames.
    }
    _rafId = requestAnimationFrame(loop);
  }

  _rafId = requestAnimationFrame(loop);
}

function _stopLoop() {
  if (_rafId !== null) {
    cancelAnimationFrame(_rafId);
    _rafId = null;
  }
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

function _b64ToBlob(b64, mimeType) {
  const binary = atob(b64);
  const bytes  = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return new Blob([bytes], { type: mimeType });
}
