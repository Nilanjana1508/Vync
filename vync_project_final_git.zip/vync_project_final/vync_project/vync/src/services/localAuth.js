// services/localAuth.js
//
// TEMPORARY PLACEHOLDER - frontend-only auth, no real backend.
//
// This exists because the real backend (a teammate's FastAPI server)
// isn't built yet. It stores accounts in this browser's localStorage
// instead of a server-side database, so it has the limitations that
// come with that:
//   - Accounts only exist on this one browser/device. Signing up here
//     does NOT create an account anyone else can log into.
//   - Passwords are stored in this browser's localStorage, NOT
//     hashed, NOT sent anywhere. This is fine for gating navigation
//     during frontend development, but it is not real security and
//     must not be treated as one. Do not reuse a real password here.
//   - Anyone with access to this browser's dev tools can read every
//     stored password in plain text.
//
// When the real FastAPI + SQLite server exists, this file is the
// only thing that needs to be swapped out - AuthContext.jsx calls
// signup() / login() / fetchCurrentUser() with the same signatures
// this file exports, so replacing the implementation underneath
// (point these functions at real HTTP calls instead) is a contained
// change.

const ACCOUNTS_STORAGE_KEY = "vync_local_accounts";
const SESSION_STORAGE_KEY = "vync_local_session_user_id";

function readAccounts() {
  try {
    const raw = localStorage.getItem(ACCOUNTS_STORAGE_KEY);
    return raw ? JSON.parse(raw) : {};
  } catch (err) {
    return {};
  }
}

function writeAccounts(accounts) {
  localStorage.setItem(ACCOUNTS_STORAGE_KEY, JSON.stringify(accounts));
}

// Same shape returned by both signup() and login(), so AuthContext
// can treat them identically.
function buildAuthResult(userId) {
  return {
    access_token: userId, // the "token" is just the user_id itself - there is no real session security here
    token_type: "local",
    user: { user_id: userId },
  };
}

/**
 * Creates a new local account. Resolves with { access_token, token_type, user }.
 * Throws an Error with a user-facing message if the user ID is already taken.
 * @param {string} userId
 * @param {string} password
 */
export async function signup(userId, password) {
  const accounts = readAccounts();

  if (accounts[userId]) {
    throw new Error("This user ID is already taken. Please choose another.");
  }

  accounts[userId] = { password };
  writeAccounts(accounts);
  localStorage.setItem(SESSION_STORAGE_KEY, userId);

  return buildAuthResult(userId);
}

/**
 * Logs in with a previously created local account. Resolves with the
 * same shape as signup(). Throws an Error with a generic "incorrect
 * credentials" message if the user ID doesn't exist or the password
 * doesn't match - intentionally the same message for both cases, so
 * this doesn't reveal which part was wrong.
 * @param {string} userId
 * @param {string} password
 */
export async function login(userId, password) {
  const accounts = readAccounts();
  const account = accounts[userId];

  if (!account || account.password !== password) {
    throw new Error("Incorrect user ID or password. Please try again.");
  }

  localStorage.setItem(SESSION_STORAGE_KEY, userId);
  return buildAuthResult(userId);
}

/**
 * Resolves the user for a previously issued "token" (here, just the
 * stored user_id). Throws if there's no matching account anymore
 * (e.g. localStorage was cleared).
 * @param {string} token
 */
export async function fetchCurrentUser(token) {
  const accounts = readAccounts();
  if (!token || !accounts[token]) {
    throw new Error("Session expired. Please log in again.");
  }
  return { user_id: token };
}
