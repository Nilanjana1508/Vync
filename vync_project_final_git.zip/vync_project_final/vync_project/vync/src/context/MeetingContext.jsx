import React, {
  createContext,
  useCallback,
  useContext,
  useMemo,
  useState,
} from "react";
import { WS_URL } from "../config/server";

const MeetingContext = createContext(null);

const DEFAULT_SERVER_URL = WS_URL;

export function MeetingProvider({ children }) {
  // Identity / session
  const [username, setUsername] = useState("");
  const [roomId, setRoomId] = useState("");
  const [serverUrl, setServerUrl] = useState(DEFAULT_SERVER_URL);

  // Connection state: "disconnected" | "connecting" | "connected"
  const [connectionState, setConnectionState] = useState("disconnected");
  const [aiServerOnline, setAiServerOnline] = useState(false);

  // Local media state
  const [cameraEnabled, setCameraEnabled] = useState(true);
  const [micEnabled, setMicEnabled] = useState(true);
  const [screenShareEnabled, setScreenShareEnabled] = useState(false);

  // Device selection
  const [devices, setDevices] = useState({ cameras: [], microphones: [] });
  const [selectedCamera, setSelectedCamera] = useState(null);
  const [selectedMicrophone, setSelectedMicrophone] = useState(null);

  // Participants - current user plus mock/remote participants for now
  const [participants, setParticipants] = useState([]);

  // Current active speaker face ID (SP101 etc) — set by speaker_update from server
  const [currentSpeaker, setCurrentSpeaker] = useState(null);

  // Chat (in-meeting)
  const [messages, setMessages] = useState([]);

  // Contacts - local address book, independent of any meeting
  const [contacts, setContacts] = useState([
    { id: "c1", name: "Aarav Mehta", email: "aarav.mehta@example.com" },
    { id: "c2", name: "Priya Nair", email: "priya.nair@example.com" },
  ]);

  // Calendar - locally scheduled meetings, keyed by ISO date string
  const [calendarEvents, setCalendarEvents] = useState([]);

  // Standalone chat (outside a meeting) - conversations keyed by contact id
  const [conversations, setConversations] = useState({});

  const addMessage = useCallback((message) => {
    setMessages((prev) => [...prev, message]);
  }, []);

  const addContact = useCallback((contact) => {
    setContacts((prev) => [...prev, contact]);
  }, []);

  const removeContact = useCallback((contactId) => {
    setContacts((prev) => prev.filter((c) => c.id !== contactId));
  }, []);

  const addCalendarEvent = useCallback((event) => {
    setCalendarEvents((prev) =>
      [...prev, event].sort((a, b) => a.dateTime.localeCompare(b.dateTime))
    );
  }, []);

  const removeCalendarEvent = useCallback((eventId) => {
    setCalendarEvents((prev) => prev.filter((e) => e.id !== eventId));
  }, []);

  const sendDirectMessage = useCallback((contactId, message) => {
    setConversations((prev) => {
      const existing = prev[contactId] || [];
      return {
        ...prev,
        [contactId]: [...existing, message],
      };
    });
  }, []);

  const resetSession = useCallback(() => {
    setConnectionState("disconnected");
    setAiServerOnline(false);
    setParticipants([]);
    setCurrentSpeaker(null);
    setMessages([]);
    setScreenShareEnabled(false);
    // Camera/mic toggles are reset here too, so a totally separate
    // future session never silently inherits "off" from a meeting
    // you left earlier. Each fresh join should start from a clean
    // "camera and mic on" state, matching how most conferencing apps
    // behave - the device hardware itself is force-synced to this on
    // the Preview screen (see MeetingPreview's init effect).
    setCameraEnabled(true);
    setMicEnabled(true);
  }, []);

  const value = useMemo(
    () => ({
      username,
      setUsername,
      roomId,
      setRoomId,
      serverUrl,
      setServerUrl,

      connectionState,
      setConnectionState,
      aiServerOnline,
      setAiServerOnline,

      cameraEnabled,
      setCameraEnabled,
      micEnabled,
      setMicEnabled,
      screenShareEnabled,
      setScreenShareEnabled,

      devices,
      setDevices,
      selectedCamera,
      setSelectedCamera,
      selectedMicrophone,
      setSelectedMicrophone,

      participants,
      setParticipants,
      currentSpeaker,
      setCurrentSpeaker,

      messages,
      setMessages,
      addMessage,

      contacts,
      setContacts,
      addContact,
      removeContact,

      calendarEvents,
      setCalendarEvents,
      addCalendarEvent,
      removeCalendarEvent,

      conversations,
      setConversations,
      sendDirectMessage,

      resetSession,
    }),
    [
      username,
      roomId,
      serverUrl,
      connectionState,
      aiServerOnline,
      cameraEnabled,
      micEnabled,
      screenShareEnabled,
      devices,
      selectedCamera,
      selectedMicrophone,
      participants,
      currentSpeaker,
      messages,
      addMessage,
      contacts,
      addContact,
      removeContact,
      calendarEvents,
      addCalendarEvent,
      removeCalendarEvent,
      conversations,
      sendDirectMessage,
      resetSession,
    ]
  );

  return (
    <MeetingContext.Provider value={value}>{children}</MeetingContext.Provider>
  );
}

export function useMeeting() {
  const ctx = useContext(MeetingContext);
  if (!ctx) {
    throw new Error("useMeeting must be used within a MeetingProvider");
  }
  return ctx;
}

export default MeetingContext;
