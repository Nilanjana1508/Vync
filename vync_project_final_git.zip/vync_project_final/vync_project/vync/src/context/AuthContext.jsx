import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from "react";
// TEMPORARY: pointed at a frontend-only localStorage placeholder
// (see services/localAuth.js) until the real FastAPI + SQLite server
// is ready. signup()/login()/fetchCurrentUser() have the same
// signatures either way, so swapping this back to the real API
// client later is a one-line change.
import * as authApi from "../services/localAuth";

const AuthContext = createContext(null);

const TOKEN_STORAGE_KEY = "vync_access_token";

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [token, setToken] = useState(null);
  // "checking" while we validate a stored token on first load, so
  // route guards don't briefly flash the login page for someone who
  // is actually already signed in.
  const [status, setStatus] = useState("checking"); // checking | authenticated | unauthenticated

  // On first load, check for a previously stored token and validate
  // it against the server before trusting it.
  useEffect(() => {
    const storedToken = localStorage.getItem(TOKEN_STORAGE_KEY);
    if (!storedToken) {
      setStatus("unauthenticated");
      return;
    }

    authApi
      .fetchCurrentUser(storedToken)
      .then((userData) => {
        setUser(userData);
        setToken(storedToken);
        setStatus("authenticated");
      })
      .catch(() => {
        localStorage.removeItem(TOKEN_STORAGE_KEY);
        setStatus("unauthenticated");
      });
  }, []);

  const signup = useCallback(async (userId, password) => {
    const data = await authApi.signup(userId, password);
    localStorage.setItem(TOKEN_STORAGE_KEY, data.access_token);
    setToken(data.access_token);
    setUser(data.user);
    setStatus("authenticated");
    return data.user;
  }, []);

  const login = useCallback(async (userId, password) => {
    const data = await authApi.login(userId, password);
    localStorage.setItem(TOKEN_STORAGE_KEY, data.access_token);
    setToken(data.access_token);
    setUser(data.user);
    setStatus("authenticated");
    return data.user;
  }, []);

  const logout = useCallback(() => {
    localStorage.removeItem(TOKEN_STORAGE_KEY);
    setToken(null);
    setUser(null);
    setStatus("unauthenticated");
  }, []);

  const value = useMemo(
    () => ({
      user,
      token,
      status,
      isAuthenticated: status === "authenticated",
      signup,
      login,
      logout,
    }),
    [user, token, status, signup, login, logout]
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return ctx;
}

export default AuthContext;
