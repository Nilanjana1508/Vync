// src/config/server.js
// Single place to update each session — never hardcode URLs elsewhere.
export const NGROK_URL = "wss://YOUR_NGROK_URL_HERE";
export const WS_URL    = `${NGROK_URL}/ws`;
export const API_URL   = NGROK_URL.replace("wss://", "https://");
