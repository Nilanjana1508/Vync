import React from "react";
import "./ParticipantPanel.css";

/**
 * Lists meeting participants. Today this is the current user plus a
 * mock remote participant; once the backend exists, real participants
 * will be pushed in via websocket "participants" updates and stored
 * in MeetingContext the same way.
 */
function ParticipantPanel({ participants, onClose }) {
  return (
    <div className="participant-panel">
      <div className="panel-header">
        <h3>Participants ({participants.length})</h3>
        <button className="panel-close" onClick={onClose} aria-label="Close participants">
          ×
        </button>
      </div>

      <div className="participant-list">
        {participants.map((p) => (
          <div key={p.id} className="participant-row">
            <div className="participant-avatar">
              {p.name.charAt(0).toUpperCase()}
            </div>
            <div className="participant-info">
              <span className="participant-name">
                {p.name}
                {p.isLocal && <span className="you-tag">You</span>}
              </span>
              <span className="participant-role">{p.role}</span>
            </div>
            <div className="participant-icons">
              <span
                className={`mic-indicator ${p.micEnabled ? "on" : "off"}`}
                title={p.micEnabled ? "Mic on" : "Mic off"}
              />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default ParticipantPanel;
