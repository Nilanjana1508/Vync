import React, { useEffect, useRef } from "react";
import "./VideoPreview.css";

/**
 * Renders a video element bound to the given MediaStream, or a
 * placeholder tile (camera-off / remote-not-connected) when no
 * stream is available.
 */
function VideoPreview({
  stream,
  streamVersion,
  label,
  muted = true,
  cameraEnabled = true,
  isLocal = false,
  placeholderText,
}) {
  const videoRef = useRef(null);

  // Track identity (not just the MediaStream object identity) drives
  // the rebind. toggleCamera() adds/removes tracks on the SAME stream
  // object in place, so `stream` never changes reference - but the
  // actual video track inside it does. Browsers don't reliably
  // refresh a <video> element's picture just because a track was
  // added to a stream it's already bound to, so srcObject must be
  // explicitly re-assigned whenever the video track itself changes.
  const videoTrack = stream ? stream.getVideoTracks()[0] : null;
  const videoTrackId = videoTrack ? videoTrack.id : null;

  useEffect(() => {
    const videoEl = videoRef.current;
    if (!videoEl) return;

    if (stream) {
      // Explicitly clear and reassign, rather than only assigning
      // when the object reference changes, to force the browser to
      // re-negotiate which tracks it's actually rendering.
      videoEl.srcObject = null;
      videoEl.srcObject = stream;
      // play() can reject if the element isn't ready yet or autoplay
      // is blocked - neither is fatal here since autoPlay is set, so
      // the error is swallowed rather than surfaced as a crash.
      const playResult = videoEl.play();
      if (playResult && typeof playResult.catch === "function") {
        playResult.catch(() => {});
      }
    } else {
      videoEl.srcObject = null;
    }
    // Re-runs whenever the stream object changes, the video track
    // inside it changes, or the caller bumps streamVersion to force a
    // rebind (used when the stream object reference is unchanged but
    // its track list was mutated in place).
  }, [stream, videoTrackId, streamVersion]);

  const showVideo = Boolean(stream) && cameraEnabled && Boolean(videoTrack);

  return (
    <div className="video-tile">
      {showVideo ? (
        <video
          ref={videoRef}
          autoPlay
          playsInline
          muted={muted}
          className={`video-element ${isLocal ? "mirrored" : ""}`}
        />
      ) : (
        <div className="video-placeholder">
          <div className="placeholder-avatar">
            {label ? label.charAt(0).toUpperCase() : "?"}
          </div>
          <span className="placeholder-text">
            {placeholderText || (cameraEnabled ? "No signal" : "Camera off")}
          </span>
        </div>
      )}

      {label && (
        <div className="video-tile-label">
          <span>{label}</span>
        </div>
      )}
    </div>
  );
}

export default VideoPreview;
