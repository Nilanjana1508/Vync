import React from "react";
import { NavLink } from "react-router-dom";
import "./Sidebar.css";

const NAV_ITEMS = [
  { to: "/", label: "Home", icon: "home" },
  { to: "/create", label: "New Meeting", icon: "new" },
  { to: "/join", label: "Join Meeting", icon: "join" },
  { to: "/calendar", label: "Calendar", icon: "calendar" },
  { to: "/chat", label: "Chat", icon: "chat" },
  { to: "/contacts", label: "Contacts", icon: "contacts" },
];

function Icon({ name }) {
  switch (name) {
    case "home":
      return (
        <svg viewBox="0 0 24 24" width="18" height="18" fill="none">
          <path
            d="M4 11.5 12 4l8 7.5M6 10v9h12v-9"
            stroke="currentColor"
            strokeWidth="1.6"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </svg>
      );
    case "new":
      return (
        <svg viewBox="0 0 24 24" width="18" height="18" fill="none">
          <circle cx="12" cy="12" r="9" stroke="currentColor" strokeWidth="1.6" />
          <path
            d="M12 8v8M8 12h8"
            stroke="currentColor"
            strokeWidth="1.6"
            strokeLinecap="round"
          />
        </svg>
      );
    case "join":
      return (
        <svg viewBox="0 0 24 24" width="18" height="18" fill="none">
          <rect
            x="3"
            y="6"
            width="13"
            height="12"
            rx="2"
            stroke="currentColor"
            strokeWidth="1.6"
          />
          <path
            d="M16 10.5 21 8v8l-5-2.5"
            stroke="currentColor"
            strokeWidth="1.6"
            strokeLinejoin="round"
          />
        </svg>
      );
    case "calendar":
      return (
        <svg viewBox="0 0 24 24" width="18" height="18" fill="none">
          <rect
            x="3"
            y="5"
            width="18"
            height="16"
            rx="2"
            stroke="currentColor"
            strokeWidth="1.6"
          />
          <path
            d="M3 9h18M8 3v4M16 3v4"
            stroke="currentColor"
            strokeWidth="1.6"
            strokeLinecap="round"
          />
        </svg>
      );
    case "chat":
      return (
        <svg viewBox="0 0 24 24" width="18" height="18" fill="none">
          <path
            d="M4 5h16v11H9l-5 4V5Z"
            stroke="currentColor"
            strokeWidth="1.6"
            strokeLinejoin="round"
          />
        </svg>
      );
    case "contacts":
      return (
        <svg viewBox="0 0 24 24" width="18" height="18" fill="none">
          <circle cx="12" cy="8" r="3.2" stroke="currentColor" strokeWidth="1.6" />
          <path
            d="M5 20c0-3.6 3.1-6 7-6s7 2.4 7 6"
            stroke="currentColor"
            strokeWidth="1.6"
            strokeLinecap="round"
          />
        </svg>
      );
    default:
      return null;
  }
}

function Sidebar() {
  return (
    <aside className="sidebar">
      <div className="sidebar-brand">
        <div className="brand-mark">V</div>
        <span className="brand-name">Vync</span>
      </div>

      <nav className="sidebar-nav">
        {NAV_ITEMS.map((item) => (
          <NavLink
            key={item.to}
            to={item.to}
            className={({ isActive }) =>
              `sidebar-link ${isActive ? "active" : ""}`
            }
            end={item.to === "/"}
          >
            <Icon name={item.icon} />
            <span>{item.label}</span>
          </NavLink>
        ))}
      </nav>

      <div className="sidebar-footer">
        <span className="sidebar-footer-text">Semantic conferencing client</span>
      </div>
    </aside>
  );
}

export default Sidebar;
