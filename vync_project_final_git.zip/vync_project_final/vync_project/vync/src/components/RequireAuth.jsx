import React from "react";
import { Navigate, useLocation } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import "../pages/Auth.css";

/**
 * Wraps a protected route. Renders the route's children only once
 * the AuthContext has confirmed a valid session with the server.
 * While that check is in flight ("checking"), a minimal loading state
 * is shown rather than flashing the login page. If there's no valid
 * session, redirects to /login and remembers where the person was
 * headed so they land there after logging in.
 */
function RequireAuth({ children }) {
  const { status, isAuthenticated } = useAuth();
  const location = useLocation();

  if (status === "checking") {
    return <div className="auth-loading-shell">Loading...</div>;
  }

  if (!isAuthenticated) {
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  return children;
}

export default RequireAuth;
