import React, { useEffect, useRef, useState } from "react";
import "./ChatPanel.css";

/**
 * Local-first chat panel. Messages are stored in MeetingContext today;
 * sendMessage is wired so a parent can later route it through the
 * websocket service once the AI server exists.
 */
function ChatPanel({ messages, currentUser, onSend, onClose }) {
  const [draft, setDraft] = useState("");
  const scrollRef = useRef(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSubmit = (e) => {
    e.preventDefault();
    const trimmed = draft.trim();
    if (!trimmed) return;
    onSend(trimmed);
    setDraft("");
  };

  return (
    <div className="chat-panel">
      <div className="panel-header">
        <h3>Chat</h3>
        <button className="panel-close" onClick={onClose} aria-label="Close chat">
          ×
        </button>
      </div>

      <div className="chat-messages" ref={scrollRef}>
        {messages.length === 0 && (
          <p className="chat-empty">No messages yet. Say hello.</p>
        )}
        {messages.map((msg) => {
          const isOwn = msg.from === currentUser;
          return (
            <div
              key={msg.id}
              className={`chat-message ${isOwn ? "own" : ""}`}
            >
              <div className="chat-message-meta">
                <span className="chat-message-author">{msg.from}</span>
                <span className="chat-message-time">
                  {new Date(msg.timestamp).toLocaleTimeString([], {
                    hour: "2-digit",
                    minute: "2-digit",
                  })}
                </span>
              </div>
              <div className="chat-message-text">{msg.text}</div>
            </div>
          );
        })}
      </div>

      <form className="chat-input-row" onSubmit={handleSubmit}>
        <input
          type="text"
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          placeholder="Type a message"
        />
        <button type="submit" disabled={!draft.trim()}>
          Send
        </button>
      </form>
    </div>
  );
}

export default ChatPanel;
