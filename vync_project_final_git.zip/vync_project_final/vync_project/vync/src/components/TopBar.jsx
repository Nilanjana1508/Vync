import React from "react";
import { useNavigate } from "react-router-dom";
import { useMeeting } from "../context/MeetingContext";
import { useAuth } from "../context/AuthContext";
import ConnectionStatus from "./ConnectionStatus";
import "./TopBar.css";

function TopBar({ title }) {
  const { connectionState, aiServerOnline } = useMeeting();
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate("/login");
  };

  return (
    <header className="topbar">
      <h1 className="topbar-title">{title}</h1>

      <div className="topbar-right">
        <ConnectionStatus
          connectionState={connectionState}
          aiServerOnline={aiServerOnline}
          compact
        />
        <div className="topbar-user">
          <div className="user-avatar">
            {user ? user.user_id.charAt(0).toUpperCase() : "?"}
          </div>
          <span className="user-name">{user ? user.user_id : "Guest"}</span>
        </div>
        <button className="topbar-logout" onClick={handleLogout} title="Log out">
          Log out
        </button>
      </div>
    </header>
  );
}

export default TopBar;
