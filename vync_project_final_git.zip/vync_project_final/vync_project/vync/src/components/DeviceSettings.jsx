import React from "react";
import "./DeviceSettings.css";

/**
 * Dropdown pair for choosing the active camera and microphone.
 * Pure presentational component - device list and selection state
 * are owned by the parent (Context API) and passed down.
 */
function DeviceSettings({
  cameras,
  microphones,
  selectedCamera,
  selectedMicrophone,
  onCameraChange,
  onMicrophoneChange,
}) {
  return (
    <div className="device-settings">
      <div className="device-field">
        <label htmlFor="camera-select">Camera</label>
        <select
          id="camera-select"
          value={selectedCamera || ""}
          onChange={(e) => onCameraChange(e.target.value)}
        >
          {cameras.length === 0 && <option value="">No camera found</option>}
          {cameras.map((cam, index) => (
            <option key={cam.deviceId} value={cam.deviceId}>
              {cam.label || `Camera ${index + 1}`}
            </option>
          ))}
        </select>
      </div>

      <div className="device-field">
        <label htmlFor="mic-select">Microphone</label>
        <select
          id="mic-select"
          value={selectedMicrophone || ""}
          onChange={(e) => onMicrophoneChange(e.target.value)}
        >
          {microphones.length === 0 && (
            <option value="">No microphone found</option>
          )}
          {microphones.map((mic, index) => (
            <option key={mic.deviceId} value={mic.deviceId}>
              {mic.label || `Microphone ${index + 1}`}
            </option>
          ))}
        </select>
      </div>
    </div>
  );
}

export default DeviceSettings;
