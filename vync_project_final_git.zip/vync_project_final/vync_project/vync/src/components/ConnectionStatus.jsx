import React from "react";
import "./ConnectionStatus.css";

/**
 * Visual indicator for socket connection state and AI server reachability.
 * connectionState: "connected" | "connecting" | "disconnected"
 */
function ConnectionStatus({ connectionState, aiServerOnline, compact }) {
  const connectionMeta = {
    connected: { label: "Connected", className: "status-good" },
    connecting: { label: "Connecting", className: "status-warn" },
    disconnected: { label: "Disconnected", className: "status-bad" },
  };

  const meta = connectionMeta[connectionState] || connectionMeta.disconnected;

  return (
    <div className={`connection-status ${compact ? "compact" : ""}`}>
      <div className="status-row">
        <span className={`status-dot ${meta.className}`} />
        <span className="status-label">{meta.label}</span>
      </div>
      {!compact && (
        <div className="status-row">
          <span
            className={`status-dot ${
              aiServerOnline ? "status-good" : "status-bad"
            }`}
          />
          <span className="status-label">
            AI Server {aiServerOnline ? "Online" : "Offline"}
          </span>
        </div>
      )}
    </div>
  );
}

export default ConnectionStatus;
