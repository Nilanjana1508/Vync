import React from "react";
import "./ControlBar.css";

function MicIcon({ off }) {
  return (
    <svg viewBox="0 0 24 24" width="20" height="20" fill="none">
      <path
        d="M9 4.5a3 3 0 0 1 6 0v6a3 3 0 0 1-6 0v-6Z"
        stroke="currentColor"
        strokeWidth="1.6"
      />
      <path
        d="M5.5 11a6.5 6.5 0 0 0 13 0M12 17.5V21M9 21h6"
        stroke="currentColor"
        strokeWidth="1.6"
        strokeLinecap="round"
      />
      {off && (
        <path
          d="M4 4 20 20"
          stroke="currentColor"
          strokeWidth="1.6"
          strokeLinecap="round"
        />
      )}
    </svg>
  );
}

function CameraIcon({ off }) {
  return (
    <svg viewBox="0 0 24 24" width="20" height="20" fill="none">
      <rect
        x="3"
        y="6"
        width="13"
        height="12"
        rx="2"
        stroke="currentColor"
        strokeWidth="1.6"
      />
      <path
        d="M16 10.5 21 8v8l-5-2.5"
        stroke="currentColor"
        strokeWidth="1.6"
        strokeLinejoin="round"
      />
      {off && (
        <path
          d="M4 4 20 20"
          stroke="currentColor"
          strokeWidth="1.6"
          strokeLinecap="round"
        />
      )}
    </svg>
  );
}

function ScreenShareIcon() {
  return (
    <svg viewBox="0 0 24 24" width="20" height="20" fill="none">
      <rect
        x="3"
        y="4"
        width="18"
        height="12"
        rx="2"
        stroke="currentColor"
        strokeWidth="1.6"
      />
      <path
        d="M8 20h8M12 16v4"
        stroke="currentColor"
        strokeWidth="1.6"
        strokeLinecap="round"
      />
    </svg>
  );
}

function ChatIcon() {
  return (
    <svg viewBox="0 0 24 24" width="20" height="20" fill="none">
      <path
        d="M4 5h16v11H9l-5 4V5Z"
        stroke="currentColor"
        strokeWidth="1.6"
        strokeLinejoin="round"
      />
    </svg>
  );
}

function ParticipantsIcon() {
  return (
    <svg viewBox="0 0 24 24" width="20" height="20" fill="none">
      <circle cx="9" cy="8" r="3" stroke="currentColor" strokeWidth="1.6" />
      <path
        d="M3.5 19c0-3 2.5-5 5.5-5s5.5 2 5.5 5"
        stroke="currentColor"
        strokeWidth="1.6"
        strokeLinecap="round"
      />
      <circle cx="17" cy="9" r="2.4" stroke="currentColor" strokeWidth="1.6" />
      <path
        d="M15 19c.2-2.2 1.7-3.8 3.8-4.3"
        stroke="currentColor"
        strokeWidth="1.6"
        strokeLinecap="round"
      />
    </svg>
  );
}

function LeaveIcon() {
  return (
    <svg viewBox="0 0 24 24" width="20" height="20" fill="none">
      <path
        d="M16 8.5 21 12l-5 3.5"
        stroke="currentColor"
        strokeWidth="1.6"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path d="M21 12H9" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
      <path
        d="M13 5H5v14h8"
        stroke="currentColor"
        strokeWidth="1.6"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

/**
 * Bottom control bar for the meeting room.
 * All toggle states and handlers are owned by MeetingRoom / Context.
 */
function ControlBar({
  micEnabled,
  cameraEnabled,
  screenShareEnabled,
  chatOpen,
  participantsOpen,
  onToggleMic,
  onToggleCamera,
  onToggleScreenShare,
  onToggleChat,
  onToggleParticipants,
  onLeave,
}) {
  return (
    <div className="control-bar">
      <div className="control-group">
        <button
          className={`control-btn ${!micEnabled ? "off" : ""}`}
          onClick={onToggleMic}
          title={micEnabled ? "Mute microphone" : "Unmute microphone"}
        >
          <MicIcon off={!micEnabled} />
        </button>

        <button
          className={`control-btn ${!cameraEnabled ? "off" : ""}`}
          onClick={onToggleCamera}
          title={cameraEnabled ? "Turn off camera" : "Turn on camera"}
        >
          <CameraIcon off={!cameraEnabled} />
        </button>

        <button
          className={`control-btn ${screenShareEnabled ? "active" : ""}`}
          onClick={onToggleScreenShare}
          title="Share screen (placeholder)"
        >
          <ScreenShareIcon />
        </button>
      </div>

      <div className="control-group">
        <button
          className={`control-btn ${chatOpen ? "active" : ""}`}
          onClick={onToggleChat}
          title="Toggle chat"
        >
          <ChatIcon />
        </button>

        <button
          className={`control-btn ${participantsOpen ? "active" : ""}`}
          onClick={onToggleParticipants}
          title="Toggle participants"
        >
          <ParticipantsIcon />
        </button>
      </div>

      <div className="control-group">
        <button className="control-btn leave-btn" onClick={onLeave} title="Leave meeting">
          <LeaveIcon />
          <span>Leave</span>
        </button>
      </div>
    </div>
  );
}

export default ControlBar;
