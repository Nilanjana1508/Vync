// utils/authValidation.js
// These are currently the ONLY validation rules in effect - there is
// no real server yet (see services/localAuth.js for why). When the
// real FastAPI server exists, it should enforce these same rules
// server-side and become the actual authority; this file would then
// go back to being a mirror for instant client-side feedback only.

export const USER_ID_PATTERN = /^[a-zA-Z0-9_]+$/;
export const USER_ID_MIN_LENGTH = 4;
export const USER_ID_MAX_LENGTH = 20;

export const PASSWORD_MIN_LENGTH = 8;
export const PASSWORD_MAX_LENGTH = 64;

/**
 * @param {string} value
 * @returns {string|null} error message, or null if valid
 */
export function validateUserId(value) {
  const trimmed = (value || "").trim();

  if (!trimmed) {
    return "User ID is required.";
  }
  if (trimmed.length < USER_ID_MIN_LENGTH) {
    return `User ID must be at least ${USER_ID_MIN_LENGTH} characters.`;
  }
  if (trimmed.length > USER_ID_MAX_LENGTH) {
    return `User ID must be ${USER_ID_MAX_LENGTH} characters or fewer.`;
  }
  if (!USER_ID_PATTERN.test(trimmed)) {
    return "User ID can only contain letters, numbers, and underscores.";
  }
  return null;
}

/**
 * @param {string} value
 * @returns {string|null} error message, or null if valid
 */
export function validatePassword(value) {
  if (!value) {
    return "Password is required.";
  }
  if (value.length < PASSWORD_MIN_LENGTH) {
    return `Password must be at least ${PASSWORD_MIN_LENGTH} characters.`;
  }
  if (value.length > PASSWORD_MAX_LENGTH) {
    return `Password must be ${PASSWORD_MAX_LENGTH} characters or fewer.`;
  }
  if (!/[A-Za-z]/.test(value)) {
    return "Password must contain at least one letter.";
  }
  if (!/[0-9]/.test(value)) {
    return "Password must contain at least one number.";
  }
  return null;
}
