// utils/roomCode.js
// Centralizes the room code format rule so every place that accepts
// a room code (Join page, Calendar's "create meeting", etc.) validates
// it the same way. Today this is local format-only validation - it
// confirms the code is *shaped* correctly, not that it exists on a
// server, since there is no server yet to check against. Once the
// FastAPI AI server is online, this is also where a "does this room
// actually exist" check would be added (likely an async function that
// asks the server) without touching the call sites.

export const ROOM_CODE_PATTERN = /^[A-Za-z]+$/;
export const ROOM_CODE_LENGTH = 10; // fixed 3-4-3 letter segments

/**
 * Validates a room code against the current format rule: exactly 10
 * letters (displayed/typed as 3-4-3 segments separated by hyphens),
 * no digits, spaces, or other symbols. This is the single source of
 * truth for "is this a well-formed room code" - generateRoomCode()
 * and formatRoomCodeInput() both produce values that satisfy this
 * same rule, so a generated code and a typed code are never out of
 * sync with each other.
 * @param {string} code
 * @returns {{ valid: boolean, error: string|null }}
 */
export function validateRoomCode(code) {
  const trimmed = stripRoomCodeFormatting(code);

  if (!trimmed) {
    return { valid: false, error: "Room code is required." };
  }

  if (/\d/.test(trimmed)) {
    return {
      valid: false,
      error: "Room code must contain letters only - no numbers.",
    };
  }

  if (!ROOM_CODE_PATTERN.test(trimmed)) {
    return {
      valid: false,
      error: "Room code can only contain letters (A-Z), no spaces or symbols.",
    };
  }

  if (trimmed.length !== ROOM_CODE_LENGTH) {
    return {
      valid: false,
      error: `Room code must be ${ROOM_CODE_LENGTH} letters, formatted as xxx-xxxx-xxx.`,
    };
  }

  return { valid: true, error: null };
}

/**
 * Normalizes a room code for storage/comparison (uppercase, trimmed).
 * Two people typing "teamsync" and "TeamSync" should land in the same
 * room once real room-joining exists, so codes are compared in a
 * consistent case.
 * @param {string} code
 * @returns {string}
 */
export function normalizeRoomCode(code) {
  return stripRoomCodeFormatting(code).toUpperCase();
}

const CODE_LETTERS = "abcdefghijklmnopqrstuvwxyz";

function randomLetters(length) {
  let result = "";
  for (let i = 0; i < length; i += 1) {
    result += CODE_LETTERS.charAt(
      Math.floor(Math.random() * CODE_LETTERS.length)
    );
  }
  return result;
}

/**
 * Generates a new, easy-to-read room code in a Meet-style segmented
 * format (e.g. "wko-fhqr-bsv"). The hyphens are purely a display/typing
 * aid - validateRoomCode and normalizeRoomCode both strip them, so a
 * code generated here passes the same letters-only rule as a manually
 * typed one once hyphens are removed.
 *
 * This is generated entirely client-side. It is guaranteed to be
 * well-formed, but - same caveat as everywhere else in this file -
 * it is NOT guaranteed to be unique or reachable by anyone else until
 * the AI server exists to register and look up real rooms.
 *
 * @returns {string} a code like "wko-fhqr-bsv"
 */
export function generateRoomCode() {
  return `${randomLetters(3)}-${randomLetters(4)}-${randomLetters(3)}`;
}

/**
 * Strips display formatting (hyphens, surrounding whitespace) from a
 * room code so it can be validated/normalized/compared as plain letters.
 * @param {string} code
 * @returns {string}
 */
export function stripRoomCodeFormatting(code) {
  return (code || "").replace(/-/g, "").trim();
}

const SEGMENT_LENGTHS = [3, 4, 3];

/**
 * Formats raw typed input into the same "xxx-xxxx-xxx" shape that
 * generateRoomCode() produces, inserting hyphens automatically as the
 * user types. This is what makes a generated code (shown on Create
 * Meeting) and a typed code (entered on Join Meeting) look and behave
 * identically - both pass through this single segmentation rule.
 *
 * Non-letter characters are dropped as they're typed rather than
 * rejected with an error, since this runs on every keystroke; the
 * full letters-only check still happens in validateRoomCode on submit.
 *
 * @param {string} rawInput
 * @returns {string} formatted value, e.g. "wko-fhqr-bsv"
 */
export function formatRoomCodeInput(rawInput) {
  const lettersOnly = (rawInput || "")
    .replace(/[^a-zA-Z]/g, "")
    .toLowerCase()
    .slice(0, SEGMENT_LENGTHS.reduce((a, b) => a + b, 0));

  const segments = [];
  let cursor = 0;
  for (const len of SEGMENT_LENGTHS) {
    if (cursor >= lettersOnly.length) break;
    segments.push(lettersOnly.slice(cursor, cursor + len));
    cursor += len;
  }

  return segments.join("-");
}
