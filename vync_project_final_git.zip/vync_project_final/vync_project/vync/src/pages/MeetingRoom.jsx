import React, { useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import TopBar from "../components/TopBar";
import ControlBar from "../components/ControlBar";
import ChatPanel from "../components/ChatPanel";
import ParticipantPanel from "../components/ParticipantPanel";
import { useMeeting } from "../context/MeetingContext";
import { useAuth } from "../context/AuthContext";
import * as media from "../services/media";
import * as ws from "../services/websocket";
import * as audioService from "../services/audioService";
import * as semanticService from "../services/semanticService";
import * as faceDetectionService from "../services/faceDetectionService";
import * as registrationService from "../services/registrationService";
import * as queueManager from "../services/queueManager";
import * as remoteVideoService from "../services/remoteVideoService";
import * as localVideoReceiver from "../services/localVideoReceiver";
import { parse } from "../services/packetParser";
import { buildJoinPacket, buildPingPacket, buildLeavePacket } from "../services/packetBuilder";
import * as localBridge from "../services/localBridge";
import "./MeetingRoom.css";

let messageIdCounter = 0;
function nextMessageId() {
  messageIdCounter += 1;
  return `local-${Date.now()}-${messageIdCounter}`;
}

function MeetingRoom() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const {
    username, roomId, serverUrl,
    micEnabled, setMicEnabled,
    screenShareEnabled, setScreenShareEnabled,
    setConnectionState, setAiServerOnline,
    participants, setParticipants,
    currentSpeaker, setCurrentSpeaker,
    messages, addMessage,
    resetSession,
  } = useMeeting();

  const [chatOpen, setChatOpen]               = useState(true);
  const [participantsOpen, setParticipantsOpen] = useState(false);
  const [registrationStatus, setRegistrationStatus] = useState(null);
  const [semanxStatus, setSemanxStatus]       = useState("disconnected");
  const [hasAiVideo, setHasAiVideo]           = useState(false);
  const [hasLocalVideo, setHasLocalVideo]     = useState(false);

  // Canvas refs
  const localCanvasRef  = useRef(null);   // semanxx JPEG frames → local tile
  const remoteCanvasRef = useRef(null);   // AI-generated talking face → remote tile

  const sessionIdRef     = useRef(`S${Date.now()}`);
  const pingIntervalRef  = useRef(null);
  const unsubscribersRef = useRef([]);
  const initialized      = useRef(false);

  // Redirect if no session context
  useEffect(() => {
    if (!username.trim() || !roomId.trim()) navigate("/join");
  }, [username, roomId, navigate]);

  // ── Attach canvas services once the DOM is ready ─────────────────────────
  useEffect(() => {
    if (localCanvasRef.current) {
      localVideoReceiver.attach(localCanvasRef.current);
    }
    if (remoteCanvasRef.current) {
      remoteVideoService.attach(remoteCanvasRef.current, {
        onFrame: () => setHasAiVideo(true),
      });
    }
    return () => {
      localVideoReceiver.detach();
      remoteVideoService.detach();
    };
  }, []);

  // ── Full session init — runs exactly once ────────────────────────────────
  useEffect(() => {
    if (initialized.current) return;
    initialized.current = true;

    async function init() {
      const sessionId = sessionIdRef.current;
      const nodeId    = 1;

      // ── Microphone only (no camera — semanxx owns it) ────────────────────
      // We still need a MediaStream for audioService (MediaRecorder).
      // Request audio-only; this will NOT conflict with semanxx's camera.
      if (micEnabled) {
        try {
          const micStream = await navigator.mediaDevices.getUserMedia({ audio: true, video: false });
          media._setActiveStream(micStream);  // store so audioService.start() can find it
        } catch (err) {
          console.warn("[MeetingRoom] Could not access microphone:", err);
        }
      }

      setParticipants([
        { id: "local",         name: username || "You",    role: "Host",  isLocal: true,  micEnabled: true },
        { id: "mock-remote-1", name: "Remote Participant", role: "Guest", isLocal: false, micEnabled: true },
      ]);

      // ── WebSocket connect ────────────────────────────────────────────────
      setConnectionState("connecting");
      let serverOnline = ws.isConnected();

      if (!serverOnline) {
        try {
          await ws.connect(serverUrl);
          serverOnline = true;
          setConnectionState("connected");
          setAiServerOnline(true);
          ws.sendPacket(buildJoinPacket({ sessionId, roomId, nodeId, displayName: username || "User" }));
        } catch (err) {
          console.warn("[MeetingRoom] AI server not reachable, running offline", err);
          setConnectionState("disconnected");
          setAiServerOnline(false);
        }
      } else {
        setConnectionState("connected");
        setAiServerOnline(true);
      }

      // ── Queue handler: speaker_update ────────────────────────────────────
      const unsubSpeaker = queueManager.onPacket("speaker_update", (packet) => {
        const spId = faceDetectionService.getOrAssignFaceId(packet.speakerId);
        console.log(`[MeetingRoom] 🎙 speaker_update — semanxx: ${packet.speakerId} → ${spId} (conf: ${packet.confidence})`);
        setCurrentSpeaker(spId || null);

        if (spId) audioService.setSpeaker(spId);

        // Forward all people's semantic data to FastAPI
        if (packet.semanticData) {
          semanticService.pushAll({
            semanticData: packet.semanticData,
            sessionId, roomId, nodeId,
            getSpId: (pid) => faceDetectionService.getOrAssignFaceId(pid),
          });
        }

        // Register face on first encounter
        if (spId && !faceDetectionService.isRegistered(spId)) {
          registrationService.runRegistration({
            sessionId, roomId, nodeId,
            faceIds:        [spId],
            onStatusChange: setRegistrationStatus,
          });
        }

        // Show the local canvas label once semanxx is sending frames
        setHasLocalVideo(true);
      });

      // ── Queue handler: AI-generated video frame ──────────────────────────
      const unsubVideo = queueManager.onPacket("video_frame", (packet) => {
        console.log(`[MeetingRoom] 🎬 video_frame — speaker: ${packet.speakerId}`);
        remoteVideoService.push(packet);
      });

      // ── Queue handler: chat ──────────────────────────────────────────────
      const unsubChat = queueManager.onPacket("message", (packet) => {
        addMessage({
          id:        nextMessageId(),
          from:      packet.raw?.from      || "Remote",
          text:      packet.raw?.text      || "",
          timestamp: packet.raw?.timestamp || Date.now(),
        });
      });

      // ── Inbound packet router ────────────────────────────────────────────
      const unsubMsg = ws.registerMessageHandler((raw) => {
        const packet = parse(raw);

        if (packet.type === "join_success") {
          console.log("[MeetingRoom] ✅ join_success", packet.roomId);
          setConnectionState("connected");
          setAiServerOnline(true);

          const localPersonId = user?.user_id || username;
          const localFaceId   = faceDetectionService.getOrAssignFaceId(localPersonId);
          registrationService.runRegistration({
            sessionId, roomId, nodeId,
            faceIds:        [localFaceId],
            onStatusChange: setRegistrationStatus,
          });

          const activeStream = media.getActiveStream();
          if (activeStream) {
            audioService.start({ stream: activeStream, sessionId, roomId, nodeId });
          }
        }

        const localPersonId = user?.user_id || username;
        const localFaceId   = faceDetectionService.getOrAssignFaceId(localPersonId);
        registrationService.handleServerPacket({
          packet, sessionId, roomId, nodeId,
          registeredIds:  [localFaceId],
          onStatusChange: setRegistrationStatus,
        });

        queueManager.enqueue(packet);
      });

      const unsubConn = ws.registerConnectionHandler((status) => {
        setConnectionState(status);
        setAiServerOnline(status === "connected");
        if (status === "connected") {
          const activeStream = media.getActiveStream();
          if (activeStream && !audioService.isRunning()) {
            audioService.start({ stream: activeStream, sessionId, roomId, nodeId });
          }
        }
      });

      // ── PING every 10 s ──────────────────────────────────────────────────
      if (serverOnline) {
        pingIntervalRef.current = setInterval(() => {
          ws.sendPacket(buildPingPacket({ sessionId, roomId, nodeId }));
        }, 10000);
      }

      // ── Local semanxx bridge ─────────────────────────────────────────────
      // TEXT  → speaker_update → queueManager
      // 0x00  → audio → localAudioPlayer
      // 0x01  → JPEG  → localVideoReceiver → local canvas
      localBridge.start({ onStatus: setSemanxStatus });

      const handleUnload = () => {
        if (ws.isConnected()) ws.sendPacket(buildLeavePacket({ sessionId, roomId, nodeId }));
      };
      window.addEventListener("beforeunload", handleUnload);

      unsubscribersRef.current = [
        unsubConn, unsubMsg, unsubSpeaker, unsubVideo, unsubChat,
        () => window.removeEventListener("beforeunload", handleUnload),
      ];
    }

    init();

    return () => {
      unsubscribersRef.current.forEach(u => u());
      unsubscribersRef.current = [];
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // ── Controls ──────────────────────────────────────────────────────────────

  const handleToggleMic = () => {
    const next = !micEnabled;
    media.toggleMic(next);
    setMicEnabled(next);
  };

  const handleToggleScreenShare = () => setScreenShareEnabled(prev => !prev);

  const handleSendMessage = (text) => {
    const message = { id: nextMessageId(), from: username || "You", text, timestamp: Date.now() };
    addMessage(message);
    ws.sendMessage(username || "You", text);
  };

  const handleLeave = () => {
    const sessionId = sessionIdRef.current;
    if (ws.isConnected()) ws.sendPacket(buildLeavePacket({ sessionId, roomId, nodeId: 1 }));
    if (pingIntervalRef.current) { clearInterval(pingIntervalRef.current); pingIntervalRef.current = null; }

    audioService.stop();
    localBridge.stop();
    localVideoReceiver.detach();
    remoteVideoService.detach();
    faceDetectionService.reset();
    registrationService.reset();
    queueManager.reset();

    unsubscribersRef.current.forEach(u => u());
    unsubscribersRef.current = [];

    ws.disconnect();
    media.stopCamera();
    resetSession();
    navigate("/");
  };

  const remoteParticipant = participants.find(p => !p.isLocal);

  return (
    <div className="room-shell">
      <TopBar title={`Room: ${roomId}`} />

      <div className="room-body">
        <div className="room-video-grid">

          {/* ── Local tile — semanxx JPEG frames ── */}
          <div className="video-tile local-tile">
            <canvas
              ref={localCanvasRef}
              className="semanxx-canvas"
              width={640}
              height={480}
            />
            {!hasLocalVideo && (
              <div className="video-placeholder">
                <span>⏳ Waiting for semanxx camera feed…</span>
                <small>run: python main.py</small>
              </div>
            )}
            <span className="video-label">
              {currentSpeaker
                ? `${username || "You"} · 🎙 ${currentSpeaker}`
                : username || "You"}
            </span>
          </div>

          {/* ── Remote tile — AI-generated talking face ── */}
          <div className="video-tile remote-tile">
            <canvas
              ref={remoteCanvasRef}
              className={`ai-canvas ${hasAiVideo ? "visible" : ""}`}
              width={640}
              height={480}
            />
            {!hasAiVideo && (
              <div className="video-placeholder">
                <span>Waiting for AI-generated stream</span>
              </div>
            )}
            {remoteParticipant && (
              <span className="video-label">{remoteParticipant.name}</span>
            )}
          </div>
        </div>

        {/* Banners */}
        {registrationStatus && (
          <div className="registration-banner">{registrationStatus}</div>
        )}
        {semanxStatus !== "connected" && (
          <div className="semanx-banner">
            {semanxStatus === "disconnected"
              ? "⏳ Waiting for semanxx... (run: python main.py)"
              : "Connecting to semanxx..."}
          </div>
        )}

        {chatOpen && (
          <ChatPanel
            messages={messages}
            currentUser={username || "You"}
            onSend={handleSendMessage}
            onClose={() => setChatOpen(false)}
          />
        )}
        {participantsOpen && (
          <ParticipantPanel
            participants={participants}
            onClose={() => setParticipantsOpen(false)}
          />
        )}
      </div>

      <ControlBar
        micEnabled={micEnabled}
        cameraEnabled={false}         /* camera owned by semanxx — always off in React */
        screenShareEnabled={screenShareEnabled}
        chatOpen={chatOpen}
        participantsOpen={participantsOpen}
        onToggleMic={handleToggleMic}
        onToggleCamera={() => {}}     /* no-op */
        onToggleScreenShare={handleToggleScreenShare}
        onToggleChat={() => setChatOpen(prev => !prev)}
        onToggleParticipants={() => setParticipantsOpen(prev => !prev)}
        onLeave={handleLeave}
      />
    </div>
  );
}

export default MeetingRoom;
