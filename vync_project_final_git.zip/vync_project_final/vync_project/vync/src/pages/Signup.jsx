import React, { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { validateUserId, validatePassword } from "../utils/authValidation";
import "./Auth.css";

function Signup() {
  const navigate = useNavigate();
  const { signup } = useAuth();

  const [userId, setUserId] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [fieldErrors, setFieldErrors] = useState({});
  const [formError, setFormError] = useState(null);
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setFormError(null);

    const nextErrors = {};
    const userIdError = validateUserId(userId);
    const passwordError = validatePassword(password);
    if (userIdError) nextErrors.userId = userIdError;
    if (passwordError) nextErrors.password = passwordError;
    if (!passwordError && confirmPassword !== password) {
      nextErrors.confirmPassword = "Passwords do not match.";
    }

    setFieldErrors(nextErrors);
    if (Object.keys(nextErrors).length > 0) return;

    setSubmitting(true);
    try {
      await signup(userId.trim(), password);
      navigate("/");
    } catch (err) {
      // Duplicate user ID is the only rejection this placeholder
      // throws right now - see services/localAuth.js.
      setFormError(err.message);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="auth-shell">
      <div className="auth-card">
        <div className="auth-brand">
          <div className="brand-mark">V</div>
          <span className="brand-name">Vync</span>
        </div>

        <h1>Create your account</h1>
        <p className="auth-subtitle">
          Sign up to start creating and joining meetings.
        </p>

        <form onSubmit={handleSubmit} className="auth-form">
          <div className="form-field">
            <label htmlFor="userId">User ID</label>
            <input
              id="userId"
              type="text"
              autoComplete="username"
              value={userId}
              onChange={(e) => setUserId(e.target.value)}
              placeholder="4-20 characters, letters/numbers/underscore"
            />
            {fieldErrors.userId && (
              <span className="field-error">{fieldErrors.userId}</span>
            )}
          </div>

          <div className="form-field">
            <label htmlFor="password">Password</label>
            <input
              id="password"
              type="password"
              autoComplete="new-password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="At least 8 characters, with a letter and a number"
            />
            {fieldErrors.password && (
              <span className="field-error">{fieldErrors.password}</span>
            )}
          </div>

          <div className="form-field">
            <label htmlFor="confirmPassword">Confirm password</label>
            <input
              id="confirmPassword"
              type="password"
              autoComplete="new-password"
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              placeholder="Re-enter your password"
            />
            {fieldErrors.confirmPassword && (
              <span className="field-error">{fieldErrors.confirmPassword}</span>
            )}
          </div>

          {formError && <div className="auth-error">{formError}</div>}

          <div className="backend-note">
            <strong>Note:</strong> accounts are currently stored only in
            this browser, not on a server - this is a placeholder until
            the real backend is ready. Don't reuse a password you use
            elsewhere.
          </div>

          <button type="submit" className="auth-submit" disabled={submitting}>
            {submitting ? "Creating account..." : "Sign up"}
          </button>
        </form>

        <p className="auth-switch">
          Already have an account? <Link to="/login">Log in</Link>
        </p>
      </div>
    </div>
  );
}

export default Signup;
