import React, { useMemo, useState } from "react";
import Sidebar from "../components/Sidebar";
import TopBar from "../components/TopBar";
import { useMeeting } from "../context/MeetingContext";
import { validateRoomCode, normalizeRoomCode, generateRoomCode, formatRoomCodeInput } from "../utils/roomCode";
import "./Calendar.css";

let eventIdCounter = 0;
function nextEventId() {
  eventIdCounter += 1;
  return `event-${Date.now()}-${eventIdCounter}`;
}

function pad(n) {
  return String(n).padStart(2, "0");
}

function toDateKey(year, month, day) {
  return `${year}-${pad(month + 1)}-${pad(day)}`;
}

function Calendar() {
  const { calendarEvents, addCalendarEvent, removeCalendarEvent } = useMeeting();

  const today = new Date();
  const [viewYear, setViewYear] = useState(today.getFullYear());
  const [viewMonth, setViewMonth] = useState(today.getMonth()); // 0-indexed
  const [selectedDate, setSelectedDate] = useState(
    toDateKey(today.getFullYear(), today.getMonth(), today.getDate())
  );

  const [title, setTitle] = useState("");
  const [time, setTime] = useState("10:00");
  const [roomCode, setRoomCode] = useState("");
  const [formErrors, setFormErrors] = useState({});

  const monthLabel = new Date(viewYear, viewMonth, 1).toLocaleString(
    "default",
    { month: "long", year: "numeric" }
  );

  const eventsByDate = useMemo(() => {
    const map = {};
    calendarEvents.forEach((evt) => {
      const key = evt.dateTime.slice(0, 10);
      if (!map[key]) map[key] = [];
      map[key].push(evt);
    });
    return map;
  }, [calendarEvents]);

  const calendarCells = useMemo(() => {
    const firstOfMonth = new Date(viewYear, viewMonth, 1);
    const startWeekday = firstOfMonth.getDay(); // 0 = Sunday
    const daysInMonth = new Date(viewYear, viewMonth + 1, 0).getDate();

    const cells = [];
    for (let i = 0; i < startWeekday; i += 1) {
      cells.push(null);
    }
    for (let day = 1; day <= daysInMonth; day += 1) {
      cells.push(day);
    }
    return cells;
  }, [viewYear, viewMonth]);

  const goToPrevMonth = () => {
    if (viewMonth === 0) {
      setViewMonth(11);
      setViewYear((y) => y - 1);
    } else {
      setViewMonth((m) => m - 1);
    }
  };

  const goToNextMonth = () => {
    if (viewMonth === 11) {
      setViewMonth(0);
      setViewYear((y) => y + 1);
    } else {
      setViewMonth((m) => m + 1);
    }
  };

  const selectedDayEvents = eventsByDate[selectedDate] || [];

  const handleAddEvent = (e) => {
    e.preventDefault();
    const nextErrors = {};

    if (!title.trim()) {
      nextErrors.title = "Meeting title is required.";
    }
    if (!time) {
      nextErrors.time = "Pick a time.";
    }

    const codeCheck = validateRoomCode(roomCode);
    if (!codeCheck.valid) {
      nextErrors.roomCode = codeCheck.error;
    }

    setFormErrors(nextErrors);
    if (Object.keys(nextErrors).length > 0) return;

    addCalendarEvent({
      id: nextEventId(),
      title: title.trim(),
      dateTime: `${selectedDate}T${time}`,
      roomCode: normalizeRoomCode(roomCode),
    });

    setTitle("");
    setRoomCode("");
  };

  return (
    <div className="page-shell">
      <Sidebar />
      <div className="page-main">
        <TopBar title="Calendar" />
        <div className="page-content calendar-content">
          <div className="calendar-layout">
            <div className="calendar-panel">
              <div className="calendar-header">
                <button className="month-nav-btn" onClick={goToPrevMonth}>
                  ‹
                </button>
                <h2>{monthLabel}</h2>
                <button className="month-nav-btn" onClick={goToNextMonth}>
                  ›
                </button>
              </div>

              <div className="calendar-weekdays">
                {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map((d) => (
                  <span key={d}>{d}</span>
                ))}
              </div>

              <div className="calendar-grid">
                {calendarCells.map((day, idx) => {
                  if (day === null) {
                    return <div key={`empty-${idx}`} className="calendar-cell empty" />;
                  }
                  const dateKey = toDateKey(viewYear, viewMonth, day);
                  const isSelected = dateKey === selectedDate;
                  const isToday =
                    dateKey ===
                    toDateKey(today.getFullYear(), today.getMonth(), today.getDate());
                  const hasEvents = Boolean(eventsByDate[dateKey]);

                  return (
                    <button
                      key={dateKey}
                      className={`calendar-cell ${isSelected ? "selected" : ""} ${
                        isToday ? "today" : ""
                      }`}
                      onClick={() => setSelectedDate(dateKey)}
                    >
                      <span>{day}</span>
                      {hasEvents && <span className="event-dot" />}
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="calendar-side-panel">
              <div className="day-events-block">
                <h3>{new Date(`${selectedDate}T00:00`).toLocaleDateString(
                  "default",
                  { weekday: "long", month: "long", day: "numeric" }
                )}</h3>

                {selectedDayEvents.length === 0 && (
                  <p className="day-events-empty">No meetings scheduled.</p>
                )}

                <div className="day-events-list">
                  {selectedDayEvents.map((evt) => (
                    <div key={evt.id} className="day-event-row">
                      <div className="day-event-info">
                        <span className="day-event-title">{evt.title}</span>
                        <span className="day-event-meta">
                          {evt.dateTime.slice(11, 16)} · Room: {evt.roomCode}
                        </span>
                      </div>
                      <button
                        className="day-event-remove"
                        onClick={() => removeCalendarEvent(evt.id)}
                        title="Remove"
                      >
                        ×
                      </button>
                    </div>
                  ))}
                </div>
              </div>

              <form className="schedule-form" onSubmit={handleAddEvent}>
                <h3>Schedule a meeting</h3>

                <div className="form-field">
                  <label htmlFor="evt-title">Title</label>
                  <input
                    id="evt-title"
                    type="text"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    placeholder="e.g. Sprint planning"
                  />
                  {formErrors.title && (
                    <span className="field-error">{formErrors.title}</span>
                  )}
                </div>

                <div className="form-field">
                  <label htmlFor="evt-time">Time</label>
                  <input
                    id="evt-time"
                    type="time"
                    value={time}
                    onChange={(e) => setTime(e.target.value)}
                  />
                  {formErrors.time && (
                    <span className="field-error">{formErrors.time}</span>
                  )}
                </div>

                <div className="form-field">
                  <label htmlFor="evt-room">Room code</label>
                  <div className="room-code-input-row">
                    <input
                      id="evt-room"
                      type="text"
                      value={roomCode}
                      onChange={(e) =>
                        setRoomCode(formatRoomCodeInput(e.target.value))
                      }
                      placeholder="wko-fhqr-bsv"
                      autoComplete="off"
                      spellCheck="false"
                      maxLength={12}
                    />
                    <button
                      type="button"
                      className="generate-code-btn"
                      onClick={() => setRoomCode(generateRoomCode())}
                    >
                      Generate
                    </button>
                  </div>
                  {formErrors.roomCode && (
                    <span className="field-error">{formErrors.roomCode}</span>
                  )}
                </div>

                <button type="submit" className="schedule-submit">
                  Add to {new Date(`${selectedDate}T00:00`).toLocaleDateString(
                    "default",
                    { month: "short", day: "numeric" }
                  )}
                </button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Calendar;
