import React, { useCallback, useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import Sidebar from "../components/Sidebar";
import TopBar from "../components/TopBar";
import ConnectionStatus from "../components/ConnectionStatus";
import DeviceSettings from "../components/DeviceSettings";
import { useMeeting } from "../context/MeetingContext";
import * as ws from "../services/websocket";
import * as media from "../services/media";
import * as localBridge from "../services/localBridge";
import * as localVideoReceiver from "../services/localVideoReceiver";
import { useAuth } from "../context/AuthContext";
import { buildJoinPacket } from "../services/packetBuilder";
import "./MeetingPreview.css";

function MeetingPreview() {
  const navigate   = useNavigate();
  const { user }   = useAuth();
  const {
    username, roomId, serverUrl,
    setConnectionState,
    micEnabled, setMicEnabled,
    devices, setDevices,
    selectedCamera, setSelectedCamera,
    selectedMicrophone, setSelectedMicrophone,
  } = useMeeting();

  const [hasLocalVideo, setHasLocalVideo] = useState(false);
  const [micStatus, setMicStatus]         = useState("connecting");
  const [semanxStatus, setSemanxStatus]   = useState("disconnected");
  const [joining, setJoining]             = useState(false);

  const localCanvasRef = useRef(null);
  const initialized    = useRef(false);

  // Redirect if no room context
  useEffect(() => {
    if (!username.trim() || !roomId.trim()) navigate("/join");
  }, [username, roomId, navigate]);

  // Attach localVideoReceiver to the preview canvas
  useEffect(() => {
    if (!localCanvasRef.current) return;
    localVideoReceiver.attach(localCanvasRef.current);
    return () => localVideoReceiver.detach();
  }, []);

  // Start local bridge so the preview canvas shows the camera feed from semanxx
  useEffect(() => {
    if (initialized.current) return;
    initialized.current = true;

    async function init() {
      // Enumerate microphone devices (no camera needed)
      try {
        // getUserMedia audio-only to unlock device labels
        const micStream = await navigator.mediaDevices.getUserMedia({ audio: true, video: false });
        media._setActiveStream(micStream);
        setMicStatus("connected");
        const { cameras, microphones } = await media.getDevices();
        setDevices({ cameras, microphones });
        if (!selectedMicrophone && microphones[0]) setSelectedMicrophone(microphones[0].deviceId);
      } catch {
        setMicStatus("disconnected");
      }

      // Connect to semanxx — preview canvas will show the camera feed
      localBridge.start({ onStatus: (s) => {
        setSemanxStatus(s);
        if (s === "connected") setHasLocalVideo(true);
      }});
    }

    init();

    return () => {
      // Don't stop the bridge here — MeetingRoom takes over after join.
      // localBridge.stop() is only called on handleLeave in MeetingRoom.
    };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleToggleMic = () => {
    const next = !micEnabled;
    media.toggleMic(next);
    setMicEnabled(next);
    setMicStatus(next ? "connected" : "disconnected");
  };

  const handleMicrophoneChange = async (deviceId) => {
    try {
      await media.switchMicrophone(deviceId);
      setSelectedMicrophone(deviceId);
    } catch (err) {
      console.error("Failed to switch microphone", err);
    }
  };

  const handleJoin = async () => {
    setJoining(true);
    setConnectionState("connecting");
    const sessionId = `S${Date.now()}`;
    try {
      await ws.connect(serverUrl);
      ws.sendPacket(buildJoinPacket({ sessionId, roomId, displayName: username || "User" }));
      setConnectionState("connected");
    } catch (err) {
      console.warn("[MeetingPreview] AI server unreachable, proceeding offline", err);
      setConnectionState("disconnected");
    } finally {
      setJoining(false);
      navigate("/room");
    }
  };

  return (
    <div className="page-shell">
      <Sidebar />
      <div className="page-main">
        <TopBar title="Meeting Preview" />
        <div className="page-content preview-content">
          <div className="preview-layout">

            {/* ── Local tile — semanxx JPEG feed ── */}
            <div className="preview-video-area">
              <div className="preview-canvas-wrapper">
                <canvas
                  ref={localCanvasRef}
                  className="preview-semanxx-canvas"
                  width={640}
                  height={480}
                />
                {!hasLocalVideo && (
                  <div className="preview-canvas-placeholder">
                    <span>
                      {semanxStatus === "connected"
                        ? "Camera feed loading…"
                        : "⏳ Run: python main.py"}
                    </span>
                    <small>semanxx provides the camera feed</small>
                  </div>
                )}
              </div>

              <div className="preview-quick-controls">
                <button
                  className={`quick-toggle ${!micEnabled ? "off" : ""}`}
                  onClick={handleToggleMic}
                >
                  {micEnabled ? "Mute" : "Unmute"}
                </button>
              </div>
            </div>

            {/* ── Side panel ── */}
            <div className="preview-side-panel">
              <h2>Ready to join, {username}?</h2>
              <p className="preview-room-info">Room: {roomId}</p>

              <div className="preview-status-block">
                <div className="status-line">
                  <span>Camera (semanxx)</span>
                  <ConnectionStatus
                    connectionState={semanxStatus === "connected" ? "connected" : "disconnected"}
                    compact
                  />
                </div>
                <div className="status-line">
                  <span>Microphone</span>
                  <ConnectionStatus connectionState={micStatus} compact />
                </div>
                <div className="status-line">
                  <span>semanxx bridge</span>
                  <ConnectionStatus
                    connectionState={semanxStatus === "connected" ? "connected" : "disconnected"}
                    compact
                  />
                </div>
              </div>

              <DeviceSettings
                cameras={[]}              /* camera managed by semanxx, not listed here */
                microphones={devices.microphones}
                selectedCamera={null}
                selectedMicrophone={selectedMicrophone}
                onCameraChange={() => {}}  /* no-op */
                onMicrophoneChange={handleMicrophoneChange}
              />

              {semanxStatus !== "connected" && (
                <div className="preview-semanx-notice">
                  ⚠️ semanxx is not running. Start it first:<br />
                  <code>cd semanxx &amp;&amp; python main.py</code>
                </div>
              )}

              <button
                className="preview-join-btn"
                onClick={handleJoin}
                disabled={joining}
              >
                {joining ? "Connecting…" : "Join meeting"}
              </button>
            </div>

          </div>
        </div>
      </div>
    </div>
  );
}

export default MeetingPreview;
