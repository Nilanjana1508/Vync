import React from "react";
import { useNavigate } from "react-router-dom";
import Sidebar from "../components/Sidebar";
import TopBar from "../components/TopBar";
import { useMeeting } from "../context/MeetingContext";
import { useAuth } from "../context/AuthContext";
import "./Dashboard.css";

const CARD_DATA = [
  {
    key: "new",
    title: "New Meeting",
    description: "Generate a fresh meeting code and start instantly.",
    cta: "Start",
    action: "create",
  },
  {
    key: "join",
    title: "Join Meeting",
    description: "Enter a room code and connect to an existing meeting.",
    cta: "Join",
    action: "join",
  },
  {
    key: "schedule",
    title: "Schedule Meeting",
    description: "Pick a date and time, and set a room code to share later.",
    cta: "Schedule",
    action: "calendar",
  },
];

function CardIcon({ name }) {
  const icons = {
    new: (
      <>
        <circle cx="12" cy="12" r="9" stroke="currentColor" strokeWidth="1.6" />
        <path
          d="M12 8v8M8 12h8"
          stroke="currentColor"
          strokeWidth="1.6"
          strokeLinecap="round"
        />
      </>
    ),
    join: (
      <path
        d="M16 10.5 21 8v8l-5-2.5M3 6h13v12H3z"
        stroke="currentColor"
        strokeWidth="1.6"
        strokeLinejoin="round"
      />
    ),
    schedule: (
      <>
        <rect x="3" y="5" width="18" height="16" rx="2" stroke="currentColor" strokeWidth="1.6" />
        <path d="M3 9h18M8 3v4M16 3v4" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
      </>
    ),
  };
  return (
    <svg viewBox="0 0 24 24" width="22" height="22" fill="none">
      {icons[name]}
    </svg>
  );
}

function Dashboard() {
  const navigate = useNavigate();
  const { connectionState } = useMeeting();
  const { user } = useAuth();

  const handleCardClick = (card) => {
    if (card.action === "join") {
      navigate("/join");
    } else if (card.action === "create") {
      navigate("/create");
    } else if (card.action === "calendar") {
      navigate("/calendar");
    }
  };

  return (
    <div className="page-shell">
      <Sidebar />
      <div className="page-main">
        <TopBar title="Home" />
        <div className="page-content dashboard-content">
          <section className="welcome-block">
            <h2>{user ? `Welcome back, ${user.user_id}` : "Welcome to Vync"}</h2>
            <p>
              Connection status:{" "}
              <span className={`inline-status ${connectionState}`}>
                {connectionState}
              </span>
            </p>
          </section>

          <div className="card-grid">
            {CARD_DATA.map((card) => (
              <button
                key={card.key}
                className={`dashboard-card ${
                  card.action === "disabled" ? "disabled" : ""
                }`}
                onClick={() => handleCardClick(card)}
              >
                <div className="dashboard-card-icon">
                  <CardIcon name={card.key} />
                </div>
                <h3>{card.title}</h3>
                <p>{card.description}</p>
                <span className="dashboard-card-cta">{card.cta} →</span>
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

export default Dashboard;
