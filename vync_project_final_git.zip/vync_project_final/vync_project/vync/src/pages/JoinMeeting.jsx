import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import Sidebar from "../components/Sidebar";
import TopBar from "../components/TopBar";
import { useMeeting } from "../context/MeetingContext";
import { useAuth } from "../context/AuthContext";
import { validateRoomCode, normalizeRoomCode, formatRoomCodeInput } from "../utils/roomCode";
import "./JoinMeeting.css";

const WS_URL_PATTERN = /^wss?:\/\/.+/i;

function JoinMeeting() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const {
    username,
    setUsername,
    roomId,
    setRoomId,
    serverUrl,
    setServerUrl,
    setCameraEnabled,
    setMicEnabled,
  } = useMeeting();

  const [errors, setErrors] = useState({});

  // Pre-fill the display name with the account's user_id the first
  // time this page is visited, so the person isn't forced to retype
  // it every time. They can still change it per meeting if they want
  // a different display name.
  useEffect(() => {
    if (!username && user) {
      setUsername(user.user_id);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user]);

  const validate = () => {
    const nextErrors = {};

    if (!username.trim()) {
      nextErrors.username = "Username is required.";
    } else if (username.trim().length < 2) {
      nextErrors.username = "Username must be at least 2 characters.";
    }

    const roomCodeCheck = validateRoomCode(roomId);
    if (!roomCodeCheck.valid) {
      nextErrors.roomId = roomCodeCheck.error;
    }

    if (!serverUrl.trim()) {
      nextErrors.serverUrl = "AI server URL is required.";
    } else if (!WS_URL_PATTERN.test(serverUrl.trim())) {
      nextErrors.serverUrl = "Must be a valid ws:// or wss:// URL.";
    }

    setErrors(nextErrors);
    return Object.keys(nextErrors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (validate()) {
      setRoomId(normalizeRoomCode(roomId));
      // Every fresh join starts with camera and mic toggled on,
      // regardless of what state a previous, separate session ended
      // in. The actual hardware is force-synced to this on the
      // Preview screen.
      setCameraEnabled(true);
      setMicEnabled(true);
      navigate("/preview");
    }
  };

  return (
    <div className="page-shell">
      <Sidebar />
      <div className="page-main">
        <TopBar title="Join Meeting" />
        <div className="page-content join-content">
          <form className="join-form" onSubmit={handleSubmit}>
            <h2>Join a meeting</h2>
            <p className="form-subtitle">
              You'll preview your camera and microphone before entering the
              room.
            </p>

            <div className="form-field">
              <label htmlFor="username">Username</label>
              <input
                id="username"
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="e.g. Nilanjana"
              />
              {errors.username && (
                <span className="field-error">{errors.username}</span>
              )}
            </div>

            <div className="form-field">
              <label htmlFor="roomId">Room code</label>
              <input
                id="roomId"
                type="text"
                value={roomId}
                onChange={(e) => setRoomId(formatRoomCodeInput(e.target.value))}
                placeholder="wko-fhqr-bsv"
                autoComplete="off"
                spellCheck="false"
                maxLength={12}
              />
              {errors.roomId && (
                <span className="field-error">{errors.roomId}</span>
              )}
              <span className="field-hint">
                10 letters, formatted as xxx-xxxx-xxx. Enter the exact code
                the host shared with you.
              </span>
            </div>

            <div className="form-field">
              <label htmlFor="serverUrl">AI Server URL</label>
              <input
                id="serverUrl"
                type="text"
                value={serverUrl}
                onChange={(e) => setServerUrl(e.target.value)}
                placeholder="ws://192.168.1.15:8000/ws"
              />
              {errors.serverUrl && (
                <span className="field-error">{errors.serverUrl}</span>
              )}
              <span className="field-hint">
                Points at the FastAPI AI server. Leave the default if you
                haven't set one up yet.
              </span>
            </div>

            <div className="backend-note">
              <strong>Note:</strong> room codes are format-checked locally
              right now. Two people actually landing in the same room
              requires the AI server to be running and reachable at the
              URL above - until then, each browser only sees itself.
            </div>

            <button type="submit" className="join-submit">
              Continue to preview
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}

export default JoinMeeting;
