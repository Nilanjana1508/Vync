import React, { useEffect, useRef, useState } from "react";
import { useLocation } from "react-router-dom";
import Sidebar from "../components/Sidebar";
import TopBar from "../components/TopBar";
import { useMeeting } from "../context/MeetingContext";
import "./Chat.css";

let dmIdCounter = 0;
function nextDmId() {
  dmIdCounter += 1;
  return `dm-${Date.now()}-${dmIdCounter}`;
}

function Chat() {
  const location = useLocation();
  const { contacts, conversations, sendDirectMessage, username } = useMeeting();

  const [activeContactId, setActiveContactId] = useState(
    location.state?.contactId || contacts[0]?.id || null
  );
  const [draft, setDraft] = useState("");
  const scrollRef = useRef(null);

  // If navigated here from Contacts with a specific contact, open that thread.
  useEffect(() => {
    if (location.state?.contactId) {
      setActiveContactId(location.state.contactId);
    }
  }, [location.state]);

  const activeContact = contacts.find((c) => c.id === activeContactId);
  const activeMessages = activeContactId ? conversations[activeContactId] || [] : [];

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [activeContactId, conversations]);

  const handleSend = (e) => {
    e.preventDefault();
    const trimmed = draft.trim();
    if (!trimmed || !activeContactId) return;

    sendDirectMessage(activeContactId, {
      id: nextDmId(),
      from: username || "You",
      text: trimmed,
      timestamp: Date.now(),
    });
    setDraft("");
  };

  const lastMessagePreview = (contactId) => {
    const thread = conversations[contactId];
    if (!thread || thread.length === 0) return "No messages yet";
    return thread[thread.length - 1].text;
  };

  return (
    <div className="page-shell">
      <Sidebar />
      <div className="page-main">
        <TopBar title="Chat" />
        <div className="page-content chat-page-content">
          {contacts.length === 0 ? (
            <div className="chat-empty-state">
              <p>You don't have any contacts yet.</p>
              <p className="chat-empty-hint">
                Add someone on the Contacts page to start a conversation.
              </p>
            </div>
          ) : (
            <div className="chat-page-layout">
              <div className="chat-contact-list">
                {contacts.map((c) => (
                  <button
                    key={c.id}
                    className={`chat-contact-row ${
                      c.id === activeContactId ? "active" : ""
                    }`}
                    onClick={() => setActiveContactId(c.id)}
                  >
                    <div className="contact-avatar">
                      {c.name.charAt(0).toUpperCase()}
                    </div>
                    <div className="chat-contact-info">
                      <span className="chat-contact-name">{c.name}</span>
                      <span className="chat-contact-preview">
                        {lastMessagePreview(c.id)}
                      </span>
                    </div>
                  </button>
                ))}
              </div>

              <div className="chat-thread">
                {activeContact ? (
                  <>
                    <div className="chat-thread-header">
                      <div className="contact-avatar">
                        {activeContact.name.charAt(0).toUpperCase()}
                      </div>
                      <div>
                        <span className="chat-thread-name">{activeContact.name}</span>
                        <span className="chat-thread-email">{activeContact.email}</span>
                      </div>
                    </div>

                    <div className="chat-thread-messages" ref={scrollRef}>
                      {activeMessages.length === 0 && (
                        <p className="chat-empty-hint centered">
                          No messages yet. Say hello to {activeContact.name}.
                        </p>
                      )}
                      {activeMessages.map((msg) => {
                        const isOwn = msg.from === (username || "You");
                        return (
                          <div
                            key={msg.id}
                            className={`chat-thread-message ${isOwn ? "own" : ""}`}
                          >
                            <div className="chat-thread-message-text">{msg.text}</div>
                            <span className="chat-thread-message-time">
                              {new Date(msg.timestamp).toLocaleTimeString([], {
                                hour: "2-digit",
                                minute: "2-digit",
                              })}
                            </span>
                          </div>
                        );
                      })}
                    </div>

                    <form className="chat-thread-input-row" onSubmit={handleSend}>
                      <input
                        type="text"
                        value={draft}
                        onChange={(e) => setDraft(e.target.value)}
                        placeholder={`Message ${activeContact.name}`}
                      />
                      <button type="submit" disabled={!draft.trim()}>
                        Send
                      </button>
                    </form>
                  </>
                ) : (
                  <div className="chat-empty-state">
                    <p>Select a contact to start chatting.</p>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default Chat;
