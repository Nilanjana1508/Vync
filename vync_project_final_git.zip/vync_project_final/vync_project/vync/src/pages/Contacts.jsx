import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import Sidebar from "../components/Sidebar";
import TopBar from "../components/TopBar";
import { useMeeting } from "../context/MeetingContext";
import "./Contacts.css";

const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

let contactIdCounter = 0;
function nextContactId() {
  contactIdCounter += 1;
  return `contact-${Date.now()}-${contactIdCounter}`;
}

function Contacts() {
  const navigate = useNavigate();
  const { contacts, addContact, removeContact } = useMeeting();

  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [errors, setErrors] = useState({});
  const [query, setQuery] = useState("");

  const handleAdd = (e) => {
    e.preventDefault();
    const nextErrors = {};

    if (!name.trim()) {
      nextErrors.name = "Name is required.";
    }
    if (!email.trim()) {
      nextErrors.email = "Email is required.";
    } else if (!EMAIL_PATTERN.test(email.trim())) {
      nextErrors.email = "Enter a valid email address.";
    }

    setErrors(nextErrors);
    if (Object.keys(nextErrors).length > 0) return;

    addContact({ id: nextContactId(), name: name.trim(), email: email.trim() });
    setName("");
    setEmail("");
  };

  const filtered = contacts.filter(
    (c) =>
      c.name.toLowerCase().includes(query.toLowerCase()) ||
      c.email.toLowerCase().includes(query.toLowerCase())
  );

  return (
    <div className="page-shell">
      <Sidebar />
      <div className="page-main">
        <TopBar title="Contacts" />
        <div className="page-content contacts-content">
          <div className="contacts-layout">
            <div className="contacts-list-panel">
              <input
                className="contacts-search"
                type="text"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Search contacts"
              />

              {filtered.length === 0 && (
                <p className="contacts-empty">
                  {contacts.length === 0
                    ? "No contacts yet. Add your first one."
                    : "No contacts match your search."}
                </p>
              )}

              <div className="contacts-list">
                {filtered.map((c) => (
                  <div key={c.id} className="contact-row">
                    <div className="contact-avatar">
                      {c.name.charAt(0).toUpperCase()}
                    </div>
                    <div className="contact-info">
                      <span className="contact-name">{c.name}</span>
                      <span className="contact-email">{c.email}</span>
                    </div>
                    <div className="contact-actions">
                      <button
                        className="contact-action-btn"
                        onClick={() => navigate("/chat", { state: { contactId: c.id } })}
                        title="Message"
                      >
                        Message
                      </button>
                      <button
                        className="contact-action-btn danger"
                        onClick={() => removeContact(c.id)}
                        title="Remove contact"
                      >
                        Remove
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <form className="contact-add-form" onSubmit={handleAdd}>
              <h3>Add a contact</h3>

              <div className="form-field">
                <label htmlFor="contact-name">Name</label>
                <input
                  id="contact-name"
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Rahul Verma"
                />
                {errors.name && <span className="field-error">{errors.name}</span>}
              </div>

              <div className="form-field">
                <label htmlFor="contact-email">Email</label>
                <input
                  id="contact-email"
                  type="text"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="e.g. rahul.verma@example.com"
                />
                {errors.email && <span className="field-error">{errors.email}</span>}
              </div>

              <button type="submit" className="contact-add-btn">
                Add contact
              </button>

              <p className="contacts-note">
                Contacts are stored locally for now and reset on refresh.
              </p>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Contacts;
