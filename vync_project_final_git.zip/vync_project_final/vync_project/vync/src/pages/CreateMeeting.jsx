import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import Sidebar from "../components/Sidebar";
import TopBar from "../components/TopBar";
import { useMeeting } from "../context/MeetingContext";
import { useAuth } from "../context/AuthContext";
import { generateRoomCode, normalizeRoomCode } from "../utils/roomCode";
import "./CreateMeeting.css";

function CreateMeeting() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const {
    username,
    setUsername,
    setRoomId,
    setCameraEnabled,
    setMicEnabled,
  } = useMeeting();

  const [code, setCode] = useState(() => generateRoomCode());
  const [copied, setCopied] = useState(false);
  const [usernameError, setUsernameError] = useState(null);

  useEffect(() => {
    if (!username && user) {
      setUsername(user.user_id);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user]);

  const handleRegenerate = () => {
    setCode(generateRoomCode());
    setCopied(false);
  };

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(code);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error("Failed to copy room code", err);
    }
  };

  const handleStart = (e) => {
    e.preventDefault();

    if (!username.trim() || username.trim().length < 2) {
      setUsernameError("Enter a name with at least 2 characters.");
      return;
    }
    setUsernameError(null);

    setRoomId(normalizeRoomCode(code));
    // Same reset as Join: a brand new meeting always starts with
    // camera and mic on, regardless of any previous session.
    setCameraEnabled(true);
    setMicEnabled(true);
    navigate("/preview");
  };

  return (
    <div className="page-shell">
      <Sidebar />
      <div className="page-main">
        <TopBar title="Create Meeting" />
        <div className="page-content create-content">
          <form className="create-form" onSubmit={handleStart}>
            <h2>Start a new meeting</h2>
            <p className="form-subtitle">
              Share this code with anyone who should join. You'll preview
              your camera and microphone before entering the room.
            </p>

            <div className="code-display-block">
              <span className="code-display-label">Meeting code</span>
              <div className="code-display-row">
                <span className="code-display-value">{code}</span>
                <button
                  type="button"
                  className="code-action-btn"
                  onClick={handleCopy}
                >
                  {copied ? "Copied" : "Copy"}
                </button>
                <button
                  type="button"
                  className="code-action-btn"
                  onClick={handleRegenerate}
                  title="Generate a different code"
                >
                  Regenerate
                </button>
              </div>
            </div>

            <div className="form-field">
              <label htmlFor="host-username">Your name</label>
              <input
                id="host-username"
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="e.g. Nilanjana"
              />
              {usernameError && (
                <span className="field-error">{usernameError}</span>
              )}
            </div>

            <div className="backend-note">
              <strong>Note:</strong> this code is generated locally and looks
              and behaves like a real meeting code, but nothing connects two
              browsers yet - that needs the AI server running. For now,
              sharing this code lets someone else join the same way you do,
              once the backend exists to match codes between sessions.
            </div>

            <button type="submit" className="create-submit">
              Continue to preview
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}

export default CreateMeeting;
