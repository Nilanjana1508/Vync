# Vync — Semantic Video Conferencing

## Folder Structure

```
vync_project/
├── vync/      React frontend
└── semanxx/   Python AI sender module
```

## How to Run

### Terminal 1 — AI Module
```bash
cd semanxx
pip install -r requirements.txt
python main.py
```
Opens the OpenCV camera window. Starts the local bridge on ws://localhost:8765.

### Terminal 2 — Frontend
```bash
cd vync
npm install
npm start
```
Opens the app at http://localhost:3000.

## Before Running

Update the ngrok URL in:
```
vync/src/config/server.js
```

## How They Connect

```
Camera → semanxx → localhost:8765 → React → FastAPI (ngrok)
```

semanxx detects faces and identifies the active speaker.
React receives speaker results via the local bridge and forwards
them to the FastAPI backend as properly-shaped protocol packets.
